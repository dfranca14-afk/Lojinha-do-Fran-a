import { PRODUCT_CATEGORIES } from '@/types';
import { Hammer, Wheat, Scroll, Gem, Tractor, ChevronRight, Package } from 'lucide-react';

const CATEGORY_ICONS: Record<string, typeof Hammer> = {
  Hammer,
  Wheat,
  Scroll,
  Gem,
  Tractor,
};

export function ProductsScreen() {
  return (
    <div className="px-4 py-5 space-y-5 animate-fade-in">
      <h2 className="font-bold text-gray-800 text-base px-1">Produtos</h2>
      <div className="grid grid-cols-2 gap-3">
        {PRODUCT_CATEGORIES.map((cat) => {
          const Icon = CATEGORY_ICONS[cat.icon] || Package;
          return (
            <div
              key={cat.id}
              className="bg-white rounded-2xl shadow-soft p-4 hover:shadow-card transition-all duration-200 cursor-pointer group"
            >
              <div className={`w-12 h-12 rounded-2xl bg-gradient-to-br ${cat.color} flex items-center justify-center mb-3 group-hover:scale-110 transition-transform`}>
                <Icon className="w-6 h-6 text-white" strokeWidth={2} />
              </div>
              <h4 className="font-semibold text-gray-800 text-sm">{cat.name}</h4>
              <p className="text-xs text-gray-400 mt-0.5 leading-relaxed">{cat.description}</p>
              <div className="flex items-center gap-1 mt-2 text-xs text-brand-blue font-medium">
                Em breve
                <ChevronRight className="w-3 h-3" />
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
