import { useState, useEffect, useRef, useMemo } from 'react';
import { useApp } from '@/store';
import { Button } from '@/components/Button';
import { Modal } from '@/components/Modal';
import { ComoColetar } from '@/screens/ComoColetar';
import {
  KITS,
  PLANS,
  PLAN_PRICES,
  PLAN_TOTAL_KITS,
  BANNER_SLIDES,
  PRODUCT_CATEGORIES,
  type KitType,
  type PlanType,
} from '@/types';
import {
  Sprout,
  Warehouse,
  Database,
  Clock,
  Scroll,
  Wheat,
  Gem,
  Tractor,
  Hammer,
  CheckCircle2,
  AlertCircle,
  QrCode,
  Wallet,
  ChevronRight,
  Tag,
  ShieldCheck,
  Package,
} from 'lucide-react';

const KIT_ICONS: Record<string, typeof Sprout> = {
  Sprout,
  Warehouse,
  Database,
};

const BANNER_ICONS: Record<string, typeof Sprout> = {
  Sprout,
  Wheat,
  Scroll,
  Tractor,
};

const CATEGORY_ICONS: Record<string, typeof Sprout> = {
  Hammer,
  Wheat,
  Scroll,
  Gem,
  Tractor,
};

interface HomeProps {
  onNavigate: (screen: 'history' | 'balance') => void;
}

export function Home({ onNavigate }: HomeProps) {
  const { addOrder, addNotification, purchaseWithBalance, balance, deliveryTimes, user, addSubscription } = useApp();
  const [selectedKit, setSelectedKit] = useState<KitType>('terra');
  const [selectedPlan, setSelectedPlan] = useState<PlanType>('1kit');
  const [tagInput, setTagInput] = useState('');
  const [clockPopup, setClockPopup] = useState(false);
  const [qrModal, setQrModal] = useState(false);
  const [balanceModal, setBalanceModal] = useState(false);
  const [successModal, setSuccessModal] = useState(false);
  const [balanceError, setBalanceError] = useState('');
  const [showComoColetar, setShowComoColetar] = useState(false);

  // Banner rotation
  const [bannerIndex, setBannerIndex] = useState(0);
  const bannerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    bannerRef.current = setInterval(() => {
      setBannerIndex((i) => (i + 1) % BANNER_SLIDES.length);
    }, 4000);
    return () => {
      if (bannerRef.current) clearInterval(bannerRef.current);
    };
  }, []);

  // Tag validation
  const tagLines = useMemo(() => tagInput.split('\n'), [tagInput]);
  const tagAnalysis = useMemo(() => {
    let valid = 0;
    let invalid = 0;
    const messages: { text: string; valid: boolean }[] = [];
    const validTags: string[] = [];
    for (const line of tagLines) {
      const trimmed = line.trim();
      if (trimmed === '') continue;
      if (trimmed.startsWith('#')) {
        valid++;
        validTags.push(trimmed);
        messages.push({ text: trimmed, valid: true });
      } else {
        invalid++;
        messages.push({ text: trimmed, valid: false });
      }
    }
    return { valid, invalid, messages, validTags };
  }, [tagLines]);

  const total = PLAN_PRICES[selectedPlan] * Math.max(tagAnalysis.valid, 0);
  const canCheckout = tagAnalysis.valid > 0;

  const selectedKitInfo = KITS.find((k) => k.id === selectedKit)!;
  const showClock = selectedPlan === '1kit';
  const currentDeliveryTime = deliveryTimes[selectedKit];

  function completeOrder(): string {
    const order = addOrder({
      kit: selectedKitInfo.name,
      plan: PLANS.find((p) => p.id === selectedPlan)!.label,
      tagCount: tagAnalysis.valid,
      total,
      tags: tagAnalysis.validTags,
      userEmail: user?.email || '',
      userName: user?.name || '',
    });

    addNotification({
      title: 'Pedido recebido!',
      message: 'Recebemos seu pedido com sucesso.',
      orderId: order.id,
    });

    // Create subscription for multi-day plans
    if (selectedPlan !== '1kit') {
      const totalKits = PLAN_TOTAL_KITS[selectedPlan];
      const startDate = new Date();
      const endDate = new Date();
      endDate.setDate(endDate.getDate() + (selectedPlan === '7dias' ? 7 : 30));
      const nextDelivery = new Date();
      nextDelivery.setDate(nextDelivery.getDate() + 1);

      addSubscription({
        plan: selectedPlan,
        kit: selectedKit,
        startDate: startDate.toISOString(),
        endDate: endDate.toISOString(),
        kitsDelivered: 0,
        totalKits,
        nextDelivery: nextDelivery.toISOString(),
      });
    }

    return order.id;
  }

  function handleQrCode() {
    if (!canCheckout) return;
    completeOrder();
    setQrModal(false);
    setSuccessModal(true);
  }

  function handlePayWithBalance() {
    setBalanceError('');
    const res = purchaseWithBalance(total);
    if (!res.ok) {
      setBalanceError(res.error || 'Saldo insuficiente.');
      return;
    }
    completeOrder();
    setBalanceModal(false);
    setSuccessModal(true);
  }

  if (showComoColetar) {
    return (
      <ComoColetar
        plan={selectedPlan}
        onNavigateHistory={() => {
          setShowComoColetar(false);
          onNavigate('history');
        }}
        onBackToStore={() => {
          setShowComoColetar(false);
          setTagInput('');
        }}
        onBack={() => setShowComoColetar(false)}
      />
    );
  }

  return (
    <div className="px-4 py-4 space-y-5 animate-fade-in">
      {/* Rotating Banner */}
      <div className="relative h-36 rounded-3xl overflow-hidden shadow-card">
        {BANNER_SLIDES.map((slide, i) => {
          const Icon = BANNER_ICONS[slide.icon] || Sprout;
          return (
            <div
              key={i}
              className={`absolute inset-0 bg-gradient-to-br ${slide.gradient} transition-opacity duration-700 ${
                i === bannerIndex ? 'opacity-100' : 'opacity-0'
              }`}
            >
              <div className="absolute right-4 top-1/2 -translate-y-1/2 opacity-20">
                <Icon className="w-24 h-24 text-white" strokeWidth={1.5} />
              </div>
              <div className="relative p-6 h-full flex flex-col justify-center">
                <h2 className="text-white font-extrabold text-xl drop-shadow-sm">
                  {slide.title}
                </h2>
                <p className="text-white/90 text-sm mt-1">{slide.subtitle}</p>
              </div>
            </div>
          );
        })}
        {/* Dots */}
        <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex gap-1.5">
          {BANNER_SLIDES.map((_, i) => (
            <div
              key={i}
              className={`h-1.5 rounded-full transition-all duration-300 ${
                i === bannerIndex ? 'w-6 bg-white' : 'w-1.5 bg-white/50'
              }`}
            />
          ))}
        </div>
      </div>

      {/* Kit Selection */}
      <section>
        <h3 className="font-bold text-gray-800 text-sm mb-3">Escolha seu Kit</h3>
        <div className="grid grid-cols-3 gap-3">
          {KITS.map((kit) => {
            const Icon = KIT_ICONS[kit.icon] || Sprout;
            const active = selectedKit === kit.id;
            return (
              <button
                key={kit.id}
                onClick={() => setSelectedKit(kit.id)}
                className={`
                  relative p-3 rounded-2xl border-2 transition-all duration-200
                  ${active
                    ? 'border-brand-blue bg-blue-50 shadow-soft scale-[1.02]'
                    : 'border-gray-100 bg-white hover:border-gray-200'
                  }
                `}
              >
                <div className={`w-10 h-10 mx-auto rounded-xl bg-gradient-to-br ${kit.bgColor} flex items-center justify-center mb-2`}>
                  <Icon className={`w-5 h-5 ${kit.color}`} strokeWidth={2} />
                </div>
                <p className={`text-xs font-semibold text-center ${active ? 'text-brand-blue' : 'text-gray-600'}`}>
                  {kit.name}
                </p>
                {active && (
                  <span className="absolute -top-1.5 -right-1.5 w-5 h-5 bg-brand-blue rounded-full flex items-center justify-center ring-2 ring-white">
                    <CheckCircle2 className="w-3 h-3 text-white" />
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* Clock — only for 1 Kit plan */}
        {showClock && (
          <div className="mt-3 flex items-center justify-center animate-fade-in">
            <button
              onClick={() => setClockPopup(true)}
              className="inline-flex items-center gap-1.5 text-sm text-gray-500 hover:text-brand-blue transition-colors"
            >
              <span className="font-semibold text-gray-700">{selectedKitInfo.name}</span>
              <Clock className="w-4 h-4" />
            </button>
          </div>
        )}
      </section>

      {/* Plans */}
      <section>
        <h3 className="font-bold text-gray-800 text-sm mb-3">Plano</h3>
        <div className="grid grid-cols-3 gap-3">
          {PLANS.map((plan) => {
            const active = selectedPlan === plan.id;
            return (
              <button
                key={plan.id}
                onClick={() => setSelectedPlan(plan.id)}
                className={`
                  py-3.5 rounded-2xl border-2 transition-all duration-200 text-sm font-semibold
                  ${active
                    ? 'border-brand-green bg-brand-green text-white shadow-soft scale-[1.02]'
                    : 'border-gray-100 bg-white text-gray-600 hover:border-gray-200'
                  }
                `}
              >
                {plan.label}
              </button>
            );
          })}
        </div>
      </section>

      {/* Tags Card */}
      <section className="bg-white rounded-3xl shadow-card p-5">
        <div className="flex items-center gap-2 mb-3">
          <Tag className="w-5 h-5 text-brand-blue" />
          <h3 className="font-bold text-gray-800 text-sm">Digite uma tag por linha (com "#")</h3>
        </div>

        <textarea
          value={tagInput}
          onChange={(e) => setTagInput(e.target.value)}
          placeholder={'#minhatag\n#outratag'}
          rows={5}
          className="w-full p-3.5 rounded-2xl bg-brand-gray border-2 border-transparent focus:border-brand-blue focus:bg-white transition-all text-gray-800 placeholder-gray-400 text-sm resize-none font-mono"
        />

        {/* Validation feedback */}
        <div className="mt-3 flex items-center justify-between">
          <span className="text-sm font-semibold text-gray-700">
            Tags válidas: <span className="text-brand-green-dark">{tagAnalysis.valid}</span>
          </span>
          {tagAnalysis.invalid > 0 && (
            <span className="text-sm text-red-500 font-medium">
              {tagAnalysis.invalid} inválida(s)
            </span>
          )}
        </div>

        {tagAnalysis.messages.length > 0 && (
          <div className="mt-2 space-y-1">
            {tagAnalysis.messages.map((msg, i) => (
              <div
                key={i}
                className={`flex items-center gap-2 text-xs rounded-lg px-2.5 py-1.5 ${
                  msg.valid ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-600'
                }`}
              >
                {msg.valid ? (
                  <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
                ) : (
                  <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                )}
                <span className="font-mono">{msg.text}</span>
                {!msg.valid && <span className="ml-auto">Sem #</span>}
              </div>
            ))}
          </div>
        )}

        {/* Total — price appears ONLY here */}
        {tagAnalysis.valid > 0 && (
          <div className="mt-4 pt-4 border-t border-gray-100 flex items-center justify-between animate-slide-up">
            <span className="text-sm text-gray-500">Total</span>
            <span className="text-2xl font-extrabold text-gray-800">
              R$ {total.toFixed(2).replace('.', ',')}
            </span>
          </div>
        )}
      </section>

      {/* Before buying — requirements card */}
      <section className="bg-white rounded-3xl shadow-card p-5">
        <div className="flex items-center gap-2 mb-3">
          <ShieldCheck className="w-5 h-5 text-brand-blue" />
          <h3 className="font-bold text-gray-800 text-sm">Antes de comprar, verifique:</h3>
        </div>
        <ul className="space-y-2.5">
          {[
            'Está adquirindo o produto desejado.',
            'A(s) tag(s) foram digitadas corretamente.',
            'O recebimento de solicitações está ativado.',
            'Há limite diário na(s) tag(s) informada(s).',
            'Poderá coletar os itens em menos de 5 horas.',
          ].map((item, i) => (
            <li key={i} className="flex items-start gap-2.5 text-sm text-gray-600">
              <CheckCircle2 className="w-4 h-4 text-brand-green shrink-0 mt-0.5" />
              <span>{item}</span>
            </li>
          ))}
        </ul>
        <div className="mt-4 bg-red-50 border border-red-100 rounded-2xl p-3.5">
          <p className="text-xs text-red-600 font-medium leading-relaxed">
            O não cumprimento dos requisitos pode resultar na perda do valor pago ou dos materiais enviados.
          </p>
        </div>
      </section>

      {/* Checkout */}
      <section className="grid grid-cols-2 gap-3">
        <Button
          variant="green"
          fullWidth
          disabled={!canCheckout}
          onClick={() => setQrModal(true)}
        >
          <QrCode className="w-5 h-5" />
          Gerar QR Code
        </Button>
        <Button
          variant="white"
          fullWidth
          disabled={!canCheckout}
          onClick={() => {
            setBalanceError('');
            setBalanceModal(true);
          }}
        >
          <Wallet className="w-5 h-5" />
          Pagar com Saldo
        </Button>
      </section>

      {/* Other Products */}
      <section>
        <h3 className="font-bold text-gray-800 text-sm mb-3">Outros Produtos</h3>
        <div className="grid grid-cols-2 gap-3">
          {PRODUCT_CATEGORIES.map((cat) => {
            const Icon = CATEGORY_ICONS[cat.icon] || Package;
            return (
              <div
                key={cat.id}
                className="bg-white rounded-2xl shadow-soft p-4 hover:shadow-card transition-all duration-200 cursor-pointer group"
              >
                <div className={`w-12 h-12 rounded-2xl bg-gradient-to-br ${cat.color} flex items-center justify-center mb-3 group-hover:scale-110 transition-transform`}>
                  <Icon className="w-6 h-6 text-white" strokeWidth={2} />
                </div>
                <h4 className="font-semibold text-gray-800 text-sm">{cat.name}</h4>
                <p className="text-xs text-gray-400 mt-0.5 leading-relaxed">{cat.description}</p>
                <div className="flex items-center gap-1 mt-2 text-xs text-brand-blue font-medium">
                  Em breve
                  <ChevronRight className="w-3 h-3" />
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* Clock Popup */}
      <Modal open={clockPopup} onClose={() => setClockPopup(false)} title={selectedKitInfo.name}>
        <div className="text-center py-2">
          <div className="w-16 h-16 mx-auto rounded-2xl bg-blue-50 flex items-center justify-center mb-4">
            <Clock className="w-8 h-8 text-brand-blue" />
          </div>
          <p className="text-sm text-gray-500 mb-1">Entrega</p>
          <p className="text-lg font-bold text-gray-800">{currentDeliveryTime}</p>
        </div>
      </Modal>

      {/* QR Code Modal */}
      <Modal open={qrModal} onClose={() => setQrModal(false)} title="QR Code de Pagamento">
        <div className="text-center py-2">
          <div className="w-44 h-44 mx-auto bg-white border-4 border-gray-100 rounded-3xl flex items-center justify-center mb-4 relative overflow-hidden">
            {/* Simulated QR */}
            <div className="grid grid-cols-8 gap-0.5 p-3">
              {Array.from({ length: 64 }).map((_, i) => (
                <div
                  key={i}
                  className={`w-3 h-3 rounded-sm ${
                    (i * 7 + i * 3) % 3 === 0 ? 'bg-gray-800' : 'bg-transparent'
                  }`}
                />
              ))}
            </div>
            <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-white/50 to-transparent animate-shimmer" />
          </div>
          <p className="text-sm text-gray-500 mb-1">Total a pagar</p>
          <p className="text-2xl font-extrabold text-gray-800 mb-4">
            R$ {total.toFixed(2).replace('.', ',')}
          </p>
          <Button variant="green" fullWidth onClick={handleQrCode}>
            <CheckCircle2 className="w-5 h-5" />
            Confirmar Pagamento
          </Button>
          <p className="text-xs text-gray-400 mt-3">
            Integração com Mercado Pago em breve.
          </p>
        </div>
      </Modal>

      {/* Balance Payment Modal */}
      <Modal open={balanceModal} onClose={() => setBalanceModal(false)} title="Pagar com Saldo">
        <div className="py-2">
          <div className="bg-brand-gray rounded-2xl p-4 mb-4">
            <div className="flex justify-between text-sm mb-2">
              <span className="text-gray-500">Saldo disponível</span>
              <span className="font-semibold text-gray-800">
                R$ {balance.toFixed(2).replace('.', ',')}
              </span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-gray-500">Total</span>
              <span className="font-semibold text-gray-800">
                R$ {total.toFixed(2).replace('.', ',')}
              </span>
            </div>
            <div className="border-t border-gray-200 mt-2 pt-2 flex justify-between">
              <span className="text-sm text-gray-500">Saldo após compra</span>
              <span className="font-bold text-brand-green-dark">
                R$ {(balance - total).toFixed(2).replace('.', ',')}
              </span>
            </div>
          </div>

          {balanceError && (
            <div className="bg-red-50 text-red-600 text-sm rounded-xl px-3.5 py-2.5 mb-3 animate-fade-in">
              {balanceError}
            </div>
          )}

          <Button variant="primary" fullWidth onClick={handlePayWithBalance} disabled={balance < total}>
            <Wallet className="w-5 h-5" />
            Confirmar Pagamento
          </Button>
        </div>
      </Modal>

      {/* Success Modal */}
      <Modal open={successModal} onClose={() => setSuccessModal(false)}>
        <div className="text-center py-2">
          <div className="w-16 h-16 mx-auto rounded-full bg-green-100 flex items-center justify-center mb-4 animate-bounce-soft">
            <CheckCircle2 className="w-8 h-8 text-brand-green" />
          </div>
          <h3 className="text-lg font-bold text-gray-800 mb-1">Pedido confirmado!</h3>
          <p className="text-sm text-gray-500 mb-5">
            Recebemos seu pedido com sucesso. Acompanhe o status no histórico.
          </p>
          <Button
            variant="primary"
            fullWidth
            onClick={() => {
              setSuccessModal(false);
              setShowComoColetar(true);
            }}
          >
            Como coletar
          </Button>
          <button
            onClick={() => {
              setSuccessModal(false);
              onNavigate('history');
            }}
            className="mt-2 w-full py-2 text-sm text-gray-400 hover:text-gray-600 transition-colors"
          >
            Ver meu pedido
          </button>
        </div>
      </Modal>
    </div>
  );
}
