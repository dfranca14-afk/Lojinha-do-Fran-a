import { useApp } from '@/store';
import type { OrderStatus } from '@/types';
import { Receipt, Package, Calendar, Tag, DollarSign, Clock } from 'lucide-react';

const STATUS_STYLES: Record<OrderStatus, string> = {
  'Pedido recebido': 'bg-blue-50 text-brand-blue',
  'Em processamento': 'bg-amber-50 text-amber-600',
  'Recebido': 'bg-green-50 text-brand-green-dark',
};

export function HistoryScreen() {
  const { orders } = useApp();

  if (orders.length === 0) {
    return (
      <div className="px-4 py-5 animate-fade-in">
        <div className="bg-white rounded-3xl shadow-card p-8 text-center">
          <div className="w-16 h-16 mx-auto rounded-2xl bg-gray-100 flex items-center justify-center mb-4">
            <Receipt className="w-8 h-8 text-gray-300" />
          </div>
          <h3 className="font-bold text-gray-700 mb-1">Nenhum pedido ainda</h3>
          <p className="text-sm text-gray-400">
            Seus pedidos aparecerão aqui assim você fizer a primeira compra.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="px-4 py-5 space-y-3 animate-fade-in">
      <h2 className="font-bold text-gray-800 text-base px-1">Histórico de Compras</h2>
      {orders.map((order) => (
        <div key={order.id} className="bg-white rounded-2xl shadow-soft p-4">
          <div className="flex items-start justify-between mb-3">
            <div className="flex items-center gap-2">
              <div className="w-9 h-9 rounded-xl bg-blue-50 flex items-center justify-center">
                <Package className="w-4.5 h-4.5 text-brand-blue" />
              </div>
              <div>
                <p className="font-semibold text-gray-800 text-sm">{order.kit}</p>
                <p className="text-xs text-gray-400">{order.plan}</p>
              </div>
            </div>
            <span
              className={`text-xs font-semibold px-2.5 py-1 rounded-full ${STATUS_STYLES[order.status]}`}
            >
              {order.status}
            </span>
          </div>

          <div className="grid grid-cols-2 gap-2 text-xs">
            <div className="flex items-center gap-1.5 text-gray-500">
              <Tag className="w-3.5 h-3.5" />
              {order.tagCount} tag(s)
            </div>
            <div className="flex items-center gap-1.5 text-gray-500">
              <DollarSign className="w-3.5 h-3.5" />
              R$ {order.total.toFixed(2).replace('.', ',')}
            </div>
            <div className="flex items-center gap-1.5 text-gray-500 col-span-2">
              <Calendar className="w-3.5 h-3.5" />
              {new Date(order.date).toLocaleString('pt-BR')}
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}
