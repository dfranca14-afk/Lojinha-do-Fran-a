import { useState, type FormEvent } from 'react';
import { useApp } from '@/store';
import { Button } from '@/components/Button';
import { Store, Mail, Lock, ArrowLeft, Info, CheckCircle2 } from 'lucide-react';

interface AuthScreenProps {
  onSuccess: () => void;
}

export function AuthScreen({ onSuccess }: AuthScreenProps) {
  const { login, signup } = useApp();
  const [mode, setMode] = useState<'login' | 'signup'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setError('');
    setLoading(true);

    setTimeout(() => {
      if (mode === 'login') {
        const res = login(email.trim(), password);
        if (!res.ok) {
          setError(res.error || 'Erro ao entrar.');
          setLoading(false);
          return;
        }
        onSuccess();
      } else {
        if (password.length < 6) {
          setError('A senha deve ter no mínimo 6 caracteres.');
          setLoading(false);
          return;
        }
        if (password !== confirmPassword) {
          setError('As senhas não coincidem.');
          setLoading(false);
          return;
        }
        const name = email.trim().split('@')[0];
        const res = signup(name, email.trim(), password);
        if (!res.ok) {
          setError(res.error || 'Erro ao cadastrar.');
          setLoading(false);
          return;
        }
        onSuccess();
      }
    }, 400);
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-green-50 flex items-center justify-center p-4">
      <div className="w-full max-w-sm">
        {/* Logo */}
        <div className="text-center mb-8 animate-slide-up">
          <div className="inline-flex items-center justify-center w-20 h-20 rounded-3xl bg-gradient-to-br from-brand-blue to-brand-green shadow-float mb-4">
            <Store className="w-10 h-10 text-white" strokeWidth={2.5} />
          </div>
          <h1 className="text-2xl font-extrabold text-gray-800 tracking-tight">
            Lojinha do França
          </h1>
          <p className="text-sm text-gray-500 mt-1">
            {mode === 'login' ? 'Bem-vindo de volta!' : 'Crie sua conta'}
          </p>
        </div>

        {/* Card */}
        <div className="bg-white rounded-3xl shadow-card p-6 animate-slide-up">
          {mode === 'signup' && (
            <button
              onClick={() => {
                setMode('login');
                setError('');
              }}
              className="flex items-center gap-1 text-sm text-gray-500 mb-4 hover:text-gray-700 transition-colors"
            >
              <ArrowLeft className="w-4 h-4" />
              Voltar
            </button>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-600 mb-1.5">
                E-mail
              </label>
              <div className="relative">
                <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="seu@email.com"
                  required
                  className="w-full pl-11 pr-4 py-3.5 rounded-2xl bg-brand-gray border-2 border-transparent focus:border-brand-blue focus:bg-white transition-all text-gray-800 placeholder-gray-400"
                />
              </div>
            </div>

            {mode === 'login' && (
              <div>
                <label className="block text-sm font-medium text-gray-600 mb-1.5">
                  Senha
                </label>
                <div className="relative">
                  <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    required
                    className="w-full pl-11 pr-4 py-3.5 rounded-2xl bg-brand-gray border-2 border-transparent focus:border-brand-blue focus:bg-white transition-all text-gray-800 placeholder-gray-400"
                  />
                </div>
              </div>
            )}

            {mode === 'signup' && (
              <>
                <div>
                  <label className="block text-sm font-medium text-gray-600 mb-1.5">
                    Criar senha
                  </label>
                  <div className="relative">
                    <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                    <input
                      type="password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="Mínimo 6 caracteres"
                      required
                      className="w-full pl-11 pr-4 py-3.5 rounded-2xl bg-brand-gray border-2 border-transparent focus:border-brand-blue focus:bg-white transition-all text-gray-800 placeholder-gray-400"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-600 mb-1.5">
                    Confirmar senha
                  </label>
                  <div className="relative">
                    <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                    <input
                      type="password"
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      placeholder="Repita a senha"
                      required
                      className="w-full pl-11 pr-4 py-3.5 rounded-2xl bg-brand-gray border-2 border-transparent focus:border-brand-blue focus:bg-white transition-all text-gray-800 placeholder-gray-400"
                    />
                  </div>
                </div>

                {/* Password match indicator */}
                {confirmPassword.length > 0 && (
                  <div className={`flex items-center gap-2 text-xs animate-fade-in ${password === confirmPassword ? 'text-brand-green-dark' : 'text-red-500'}`}>
                    {password === confirmPassword ? (
                      <>
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        As senhas coincidem
                      </>
                    ) : (
                      <>
                        <Info className="w-3.5 h-3.5" />
                        As senhas não coincidem
                      </>
                    )}
                  </div>
                )}

                {/* Discreet warning */}
                <div className="bg-blue-50 border border-blue-100 rounded-2xl p-3 flex items-start gap-2">
                  <Info className="w-4 h-4 text-brand-blue shrink-0 mt-0.5" />
                  <p className="text-xs text-gray-500 leading-relaxed">
                    A senha criada é para acessar sua conta na Lojinha do França, não é a senha do seu e-mail.
                  </p>
                </div>
              </>
            )}

            {error && (
              <div className="bg-red-50 text-red-600 text-sm rounded-2xl px-4 py-3 animate-fade-in">
                {error}
              </div>
            )}

            {mode === 'signup' && (
              <p className="text-xs text-gray-400 leading-relaxed">
                Você receberá um e-mail de confirmação para ativar sua conta.
              </p>
            )}

            <Button type="submit" variant="primary" fullWidth disabled={loading}>
              {loading ? 'Aguarde...' : mode === 'login' ? 'Entrar' : 'Criar conta'}
            </Button>
          </form>

          {mode === 'login' && (
            <div className="mt-4 pt-4 border-t border-gray-100">
              <Button
                variant="secondary"
                fullWidth
                onClick={() => {
                  setMode('signup');
                  setError('');
                  setPassword('');
                  setConfirmPassword('');
                }}
              >
                Criar conta
              </Button>
            </div>
          )}
        </div>

        <p className="text-center text-xs text-gray-400 mt-6">
          Lojinha do França — Sua fazenda, mais leve.
        </p>
      </div>
    </div>
  );
}
