import { useState, useRef, useEffect } from 'react';
import { useApp } from '@/store';
import { Button } from '@/components/Button';
import { Send, MessageCircle } from 'lucide-react';

export function ChatScreen() {
  const { chatMessages, sendChatMessage } = useApp();
  const [input, setInput] = useState('');
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [chatMessages]);

  function handleSend() {
    if (input.trim() === '') return;
    sendChatMessage(input.trim());
    setInput('');
  }

  return (
    <div className="flex flex-col animate-fade-in" style={{ height: 'calc(100vh - 3.5rem)' }}>
      {/* Messages */}
      <div ref={scrollRef} className="flex-1 overflow-y-auto px-4 py-4 space-y-3">
        {chatMessages.map((msg) => (
          <div
            key={msg.id}
            className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            <div
              className={`
                max-w-[75%] px-4 py-2.5 rounded-2xl text-sm
                ${
                  msg.sender === 'user'
                    ? 'bg-brand-blue text-white rounded-br-md'
                    : 'bg-white text-gray-700 shadow-soft rounded-bl-md'
                }
              `}
            >
              {msg.text}
            </div>
          </div>
        ))}
      </div>

      {/* Input */}
      <div className="border-t border-gray-100 bg-white px-4 py-3 safe-bottom">
        <div className="flex items-center gap-2">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            placeholder="Digite sua mensagem..."
            className="flex-1 px-4 py-3 rounded-2xl bg-brand-gray border-2 border-transparent focus:border-brand-blue focus:bg-white transition-all text-gray-800 placeholder-gray-400 text-sm"
          />
          <button
            onClick={handleSend}
            disabled={input.trim() === ''}
            className="w-11 h-11 rounded-2xl bg-brand-blue text-white flex items-center justify-center disabled:opacity-40 transition-all active:scale-95"
          >
            <Send className="w-5 h-5" />
          </button>
        </div>
      </div>
    </div>
  );
}
