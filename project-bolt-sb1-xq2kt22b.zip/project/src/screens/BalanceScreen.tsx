import { useState } from 'react';
import { useApp } from '@/store';
import { Button } from '@/components/Button';
import { Modal } from '@/components/Modal';
import { Wallet, Plus, ArrowDownLeft, ArrowUpRight, TrendingUp } from 'lucide-react';

const QUICK_AMOUNTS = [10, 20, 50, 100];

export function BalanceScreen() {
  const { balance, addBalance, transactions } = useApp();
  const [addModal, setAddModal] = useState(false);
  const [amount, setAmount] = useState('');

  function handleAdd() {
    const val = parseFloat(amount.replace(',', '.'));
    if (isNaN(val) || val <= 0) return;
    addBalance(val);
    setAmount('');
    setAddModal(false);
  }

  return (
    <div className="px-4 py-5 space-y-5 animate-fade-in">
      {/* Balance Card */}
      <div className="bg-gradient-to-br from-brand-blue to-brand-blue-light rounded-3xl shadow-card p-6 text-white">
        <div className="flex items-center gap-2 mb-3">
          <Wallet className="w-5 h-5" />
          <span className="text-sm text-white/80">Saldo disponível</span>
        </div>
        <p className="text-4xl font-extrabold tracking-tight">
          R$ {balance.toFixed(2).replace('.', ',')}
        </p>
        <button
          onClick={() => setAddModal(true)}
          className="mt-5 w-full bg-white/20 hover:bg-white/30 transition-colors rounded-2xl py-3 font-semibold text-sm flex items-center justify-center gap-2"
        >
          <Plus className="w-4 h-4" />
          Adicionar saldo
        </button>
      </div>

      {/* Statement */}
      <div>
        <h3 className="font-bold text-gray-800 text-sm mb-3 flex items-center gap-2">
          <TrendingUp className="w-4 h-4 text-gray-500" />
          Extrato
        </h3>
        {transactions.length === 0 ? (
          <div className="bg-white rounded-2xl shadow-soft p-6 text-center">
            <p className="text-sm text-gray-400">Nenhuma transação ainda.</p>
          </div>
        ) : (
          <div className="space-y-2">
            {transactions.map((t) => (
              <div
                key={t.id}
                className="bg-white rounded-2xl shadow-soft p-4 flex items-center gap-3"
              >
                <div
                  className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
                    t.amount > 0 ? 'bg-green-50' : 'bg-red-50'
                  }`}
                >
                  {t.amount > 0 ? (
                    <ArrowDownLeft className="w-5 h-5 text-brand-green" />
                  ) : (
                    <ArrowUpRight className="w-5 h-5 text-red-500" />
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold text-gray-800">{t.description}</p>
                  <p className="text-xs text-gray-400">
                    {new Date(t.date).toLocaleString('pt-BR')}
                  </p>
                </div>
                <span
                  className={`text-sm font-bold ${
                    t.amount > 0 ? 'text-brand-green-dark' : 'text-red-500'
                  }`}
                >
                  {t.amount > 0 ? '+' : ''}R$ {Math.abs(t.amount).toFixed(2).replace('.', ',')}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Add Balance Modal */}
      <Modal open={addModal} onClose={() => setAddModal(false)} title="Adicionar saldo">
        <div className="py-2">
          <div className="grid grid-cols-4 gap-2 mb-4">
            {QUICK_AMOUNTS.map((amt) => (
              <button
                key={amt}
                onClick={() => setAmount(String(amt))}
                className="py-2.5 rounded-xl bg-brand-gray hover:bg-blue-50 hover:text-brand-blue transition-colors text-sm font-semibold text-gray-700"
              >
                R${amt}
              </button>
            ))}
          </div>
          <div className="relative mb-4">
            <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 font-medium">
              R$
            </span>
            <input
              type="text"
              inputMode="decimal"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="0,00"
              className="w-full pl-11 pr-4 py-3.5 rounded-2xl bg-brand-gray border-2 border-transparent focus:border-brand-blue focus:bg-white transition-all text-gray-800 font-semibold"
            />
          </div>
          <Button variant="primary" fullWidth onClick={handleAdd} disabled={!amount}>
            Confirmar
          </Button>
          <p className="text-xs text-gray-400 mt-3 text-center">
            Pagamento via PIX será integrado em breve.
          </p>
        </div>
      </Modal>
    </div>
  );
}
