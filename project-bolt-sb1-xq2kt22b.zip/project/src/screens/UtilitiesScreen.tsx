import { PRODUCT_CATEGORIES } from '@/types';
import { Calculator, Sprout, TreePine, Building2, ChevronRight } from 'lucide-react';

const UTILITIES = [
  { id: 'calc-celeiro', name: 'Calculadora de Celeiro', icon: Calculator, color: 'from-amber-400 to-orange-500' },
  { id: 'expansao', name: 'Expansão de Terrenos', icon: Sprout, color: 'from-green-400 to-green-600' },
  { id: 'lucro-arvores', name: 'Lucro de Árvores', icon: TreePine, color: 'from-lime-400 to-green-500' },
  { id: 'edificios', name: 'Edifícios de Produção', icon: Building2, color: 'from-blue-400 to-brand-blue' },
];

export function UtilitiesScreen() {
  return (
    <div className="px-4 py-5 space-y-5 animate-fade-in">
      <h2 className="font-bold text-gray-800 text-base px-1">Utilidades</h2>
      <div className="space-y-3">
        {UTILITIES.map((util) => {
          const Icon = util.icon;
          return (
            <div
              key={util.id}
              className="bg-white rounded-2xl shadow-soft p-4 flex items-center gap-4"
            >
              <div className={`w-12 h-12 rounded-2xl bg-gradient-to-br ${util.color} flex items-center justify-center shrink-0`}>
                <Icon className="w-6 h-6 text-white" strokeWidth={2} />
              </div>
              <div className="flex-1">
                <p className="font-semibold text-gray-800 text-sm">{util.name}</p>
                <p className="text-xs text-brand-blue font-medium mt-0.5">Em breve</p>
              </div>
              <ChevronRight className="w-5 h-5 text-gray-300" />
            </div>
          );
        })}
      </div>
    </div>
  );
}
