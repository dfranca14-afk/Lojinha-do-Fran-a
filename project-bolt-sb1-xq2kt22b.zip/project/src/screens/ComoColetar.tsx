import { Button } from '@/components/Button';
import {
  Package,
  Clock,
  AlertTriangle,
  CheckCircle2,
  History,
  Store,
  ArrowLeft,
  Info,
} from 'lucide-react';

interface ComoColetarProps {
  plan: '1kit' | '7dias' | '30dias';
  onNavigateHistory: () => void;
  onBackToStore: () => void;
  onBack: () => void;
}

export function ComoColetar({ plan, onNavigateHistory, onBackToStore, onBack }: ComoColetarProps) {
  const isSingleKit = plan === '1kit';

  return (
    <div className="px-4 py-5 space-y-5 animate-fade-in">
      <button
        onClick={onBack}
        className="flex items-center gap-1 text-sm text-gray-500 hover:text-gray-700 transition-colors"
      >
        <ArrowLeft className="w-4 h-4" />
        Voltar
      </button>

      {/* Header */}
      <div className="bg-gradient-to-br from-brand-blue to-brand-green rounded-3xl shadow-card p-6 text-white text-center">
        <div className="w-16 h-16 mx-auto rounded-2xl bg-white/20 flex items-center justify-center mb-3">
          <Package className="w-8 h-8 text-white" />
        </div>
        <h1 className="text-xl font-bold">Como coletar</h1>
        <p className="text-sm text-white/80 mt-1">
          {isSingleKit ? 'Instruções para 1 Kit' : 'Como funcionam as entregas'}
        </p>
      </div>

      {isSingleKit ? (
        /* 1 Kit instructions */
        <div className="bg-white rounded-3xl shadow-card p-5 space-y-4">
          <div className="flex items-center gap-2 mb-2">
            <Clock className="w-5 h-5 text-brand-blue" />
            <h2 className="font-bold text-gray-800 text-sm">Como coletar</h2>
          </div>

          <ul className="space-y-3">
            {[
              'As solicitações serão enviadas dentro do prazo informado abaixo do produto.',
              'Aguarde cerca de 20 segundos antes de aceitar.',
              'Não recuse solicitações.',
              'Colete tudo em menos de 5 horas.',
              'Itens não coletados serão perdidos.',
            ].map((item, i) => (
              <li key={i} className="flex items-start gap-2.5 text-sm text-gray-600">
                <CheckCircle2 className="w-4 h-4 text-brand-green shrink-0 mt-0.5" />
                <span>{item}</span>
              </li>
            ))}
          </ul>

          <div className="bg-amber-50 border border-amber-100 rounded-2xl p-3.5 flex items-start gap-2">
            <AlertTriangle className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
            <p className="text-xs text-amber-700 leading-relaxed">
              Itens não coletados dentro do prazo serão perdidos sem reembolso.
            </p>
          </div>
        </div>
      ) : (
        /* 7 Days and 30 Days instructions */
        <div className="bg-white rounded-3xl shadow-card p-5 space-y-4">
          <div className="flex items-center gap-2 mb-2">
            <Info className="w-5 h-5 text-brand-blue" />
            <h2 className="font-bold text-gray-800 text-sm">Como funcionam as entregas</h2>
          </div>

          <p className="text-sm text-gray-600">
            As 3 solicitações diárias são distribuídas assim:
          </p>

          <div className="space-y-2">
            {[
              { farm: 'Fazenda 1', items: '29 itens' },
              { farm: 'Fazenda 2', items: '30 itens' },
              { farm: 'Fazenda 3', items: '30 itens' },
            ].map((farm, i) => (
              <div key={i} className="flex items-center justify-between bg-brand-gray rounded-2xl px-4 py-3">
                <span className="text-sm font-semibold text-gray-700">{farm.farm}</span>
                <span className="text-sm text-gray-500">{farm.items}</span>
              </div>
            ))}
          </div>

          <div className="bg-gradient-to-r from-brand-blue to-brand-green rounded-2xl p-4 text-center">
            <p className="text-sm text-white/80">Total</p>
            <p className="text-2xl font-extrabold text-white">89 itens por dia</p>
          </div>

          <div className="bg-blue-50 border border-blue-100 rounded-2xl p-3.5 flex items-start gap-2">
            <Info className="w-4 h-4 text-brand-blue shrink-0 mt-0.5" />
            <p className="text-xs text-gray-500 leading-relaxed">
              Em alguns dias poderá existir apenas uma solicitação contendo os 89 itens.
            </p>
          </div>
        </div>
      )}

      {/* Action buttons */}
      <div className="space-y-3">
        <Button variant="primary" fullWidth onClick={onNavigateHistory}>
          <History className="w-5 h-5" />
          Ir para Histórico
        </Button>
        <Button variant="secondary" fullWidth onClick={onBackToStore}>
          <Store className="w-5 h-5" />
          Voltar à Loja
        </Button>
      </div>
    </div>
  );
}
