import { GraduationCap, ChevronRight, PlayCircle } from 'lucide-react';

const TUTORIALS = [
  { id: 1, title: 'Como comprar seu primeiro kit', duration: '2 min' },
  { id: 2, title: 'Como adicionar saldo', duration: '1 min' },
  { id: 3, title: 'Como usar tags corretamente', duration: '3 min' },
  { id: 4, title: 'Como acompanhar seu pedido', duration: '1 min' },
];

export function TutorialsScreen() {
  return (
    <div className="px-4 py-5 space-y-5 animate-fade-in">
      <div className="bg-gradient-to-br from-brand-blue to-brand-blue-light rounded-3xl shadow-card p-6 text-white text-center">
        <div className="w-14 h-14 mx-auto rounded-2xl bg-white/20 flex items-center justify-center mb-3">
          <GraduationCap className="w-7 h-7" />
        </div>
        <h2 className="text-lg font-bold">Tutoriais</h2>
        <p className="text-sm text-white/80 mt-1">
          Aprenda a usar a Lojinha do França em poucos minutos.
        </p>
      </div>

      <div className="space-y-3">
        {TUTORIALS.map((t) => (
          <div
            key={t.id}
            className="bg-white rounded-2xl shadow-soft p-4 flex items-center gap-3 hover:shadow-card transition-all cursor-pointer"
          >
            <div className="w-11 h-11 rounded-xl bg-blue-50 flex items-center justify-center shrink-0">
              <PlayCircle className="w-6 h-6 text-brand-blue" />
            </div>
            <div className="flex-1">
              <p className="font-semibold text-gray-800 text-sm">{t.title}</p>
              <p className="text-xs text-gray-400 mt-0.5">{t.duration}</p>
            </div>
            <ChevronRight className="w-5 h-5 text-gray-300" />
          </div>
        ))}
      </div>
    </div>
  );
}
