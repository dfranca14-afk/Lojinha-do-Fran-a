import { useState } from 'react';
import { useApp } from '@/store';
import { Button } from '@/components/Button';
import { Modal } from '@/components/Modal';
import {
  UserCircle,
  Mail,
  Lock,
  LogOut,
  Edit2,
  Check,
  Calendar,
  Package,
  TrendingUp,
  Clock,
  ChevronRight,
} from 'lucide-react';
import { KITS, PLAN_TOTAL_KITS, type PlanType } from '@/types';

interface AccountScreenProps {
  onNavigate: (screen: 'plans' | 'home' | 'history') => void;
}

export function AccountScreen({ onNavigate }: AccountScreenProps) {
  const { user, updateName, updatePassword, logout, subscriptions, orders } = useApp();
  const [editingName, setEditingName] = useState(false);
  const [newName, setNewName] = useState(user?.name || '');
  const [pwModal, setPwModal] = useState(false);
  const [currentPw, setCurrentPw] = useState('');
  const [newPw, setNewPw] = useState('');
  const [pwError, setPwError] = useState('');
  const [nameError, setNameError] = useState('');

  function saveName() {
    if (newName.trim().length < 2) {
      setNameError('Nome muito curto.');
      return;
    }
    updateName(newName.trim());
    setEditingName(false);
    setNameError('');
  }

  function handlePwChange() {
    setPwError('');
    if (newPw.length < 6) {
      setPwError('A nova senha deve ter no mínimo 6 caracteres.');
      return;
    }
    const res = updatePassword(currentPw, newPw);
    if (!res.ok) {
      setPwError(res.error || 'Erro ao alterar senha.');
      return;
    }
    setPwModal(false);
    setCurrentPw('');
    setNewPw('');
  }

  // Get the most recent subscription
  const activeSub = subscriptions[0];
  const userOrders = orders.filter((o) => o.userEmail === user?.email);
  const deliveredKits = userOrders.filter((o) => o.status === 'Recebido').length;

  return (
    <div className="px-4 py-5 space-y-5 animate-fade-in">
      {/* Profile header */}
      <div className="bg-white rounded-3xl shadow-card p-6 text-center">
        <div className="w-20 h-20 mx-auto rounded-3xl bg-gradient-to-br from-brand-blue to-brand-green flex items-center justify-center mb-4">
          <UserCircle className="w-10 h-10 text-white" strokeWidth={2} />
        </div>
        {editingName ? (
          <div className="flex items-center gap-2 justify-center mb-2">
            <input
              type="text"
              value={newName}
              onChange={(e) => setNewName(e.target.value)}
              className="text-center text-lg font-bold text-gray-800 border-2 border-brand-blue rounded-xl px-3 py-1.5"
            />
            <button
              onClick={saveName}
              className="w-9 h-9 rounded-xl bg-brand-green text-white flex items-center justify-center"
            >
              <Check className="w-4 h-4" />
            </button>
          </div>
        ) : (
          <div className="flex items-center gap-2 justify-center mb-2">
            <h2 className="text-xl font-bold text-gray-800">{user?.name}</h2>
            <button
              onClick={() => {
                setNewName(user?.name || '');
                setEditingName(true);
              }}
              className="w-8 h-8 rounded-lg bg-gray-100 hover:bg-gray-200 flex items-center justify-center transition-colors"
            >
              <Edit2 className="w-3.5 h-3.5 text-gray-500" />
            </button>
          </div>
        )}
        {nameError && <p className="text-xs text-red-500 mt-1">{nameError}</p>}
        <p className="text-sm text-gray-400 flex items-center justify-center gap-1.5">
          <Mail className="w-4 h-4" />
          {user?.email}
        </p>
      </div>

      {/* Área de Planos */}
      <div>
        <h3 className="font-bold text-gray-800 text-sm mb-3 px-1">Área de Planos</h3>

        {activeSub ? (
          <div className="bg-white rounded-3xl shadow-card p-5">
            {/* Plan info */}
            <div className="flex items-center justify-between mb-4">
              <div>
                <p className="text-xs text-gray-400">Plano atual</p>
                <p className="font-bold text-gray-800">
                  {activeSub.plan === '1kit' ? '1 Kit' : activeSub.plan === '7dias' ? '7 Dias' : '30 Dias'}
                </p>
              </div>
              <div className="text-right">
                <p className="text-xs text-gray-400">Kit escolhido</p>
                <p className="font-bold text-gray-800">
                  {KITS.find((k) => k.id === activeSub.kit)?.name || '—'}
                </p>
              </div>
            </div>

            {/* Dates */}
            <div className="grid grid-cols-2 gap-3 mb-4">
              <div className="bg-brand-gray rounded-xl p-3">
                <p className="text-xs text-gray-400 flex items-center gap-1 mb-1">
                  <Calendar className="w-3 h-3" />
                  Início
                </p>
                <p className="text-sm font-semibold text-gray-700">
                  {new Date(activeSub.startDate).toLocaleDateString('pt-BR')}
                </p>
              </div>
              <div className="bg-brand-gray rounded-xl p-3">
                <p className="text-xs text-gray-400 flex items-center gap-1 mb-1">
                  <Calendar className="w-3 h-3" />
                  Término
                </p>
                <p className="text-sm font-semibold text-gray-700">
                  {new Date(activeSub.endDate).toLocaleDateString('pt-BR')}
                </p>
              </div>
            </div>

            {/* Progress bar */}
            <div className="mb-4">
              <div className="flex items-center justify-between text-sm mb-2">
                <span className="text-gray-500 flex items-center gap-1.5">
                  <Package className="w-4 h-4" />
                  Kits entregues
                </span>
                <span className="font-bold text-gray-800">
                  {activeSub.kitsDelivered} de {activeSub.totalKits} kits
                </span>
              </div>
              <div className="h-3 bg-gray-100 rounded-full overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-brand-green to-brand-green-dark rounded-full transition-all duration-500"
                  style={{
                    width: `${(activeSub.kitsDelivered / activeSub.totalKits) * 100}%`,
                  }}
                />
              </div>
              <p className="text-xs text-gray-400 mt-1.5">
                {activeSub.totalKits - activeSub.kitsDelivered} kits restantes
              </p>
            </div>

            {/* Next delivery */}
            <div className="bg-blue-50 rounded-xl p-3 flex items-center gap-2">
              <Clock className="w-4 h-4 text-brand-blue shrink-0" />
              <div>
                <p className="text-xs text-gray-400">Próxima entrega</p>
                <p className="text-sm font-semibold text-brand-blue">
                  {new Date(activeSub.nextDelivery).toLocaleDateString('pt-BR')}
                </p>
              </div>
            </div>
          </div>
        ) : (
          <div className="bg-white rounded-3xl shadow-soft p-6 text-center">
            <TrendingUp className="w-10 h-10 text-gray-300 mx-auto mb-3" />
            <p className="text-sm text-gray-400 mb-3">
              Você ainda não possui um plano ativo.
            </p>
            <Button variant="primary" onClick={() => onNavigate('home')}>
              Ver planos disponíveis
            </Button>
          </div>
        )}
      </div>

      {/* Actions */}
      <div className="space-y-3">
        <button
          onClick={() => setPwModal(true)}
          className="w-full bg-white rounded-2xl shadow-soft p-4 flex items-center gap-3 hover:shadow-card transition-all"
        >
          <div className="w-10 h-10 rounded-xl bg-blue-50 flex items-center justify-center">
            <Lock className="w-5 h-5 text-brand-blue" />
          </div>
          <span className="text-sm font-semibold text-gray-700 flex-1 text-left">Alterar senha</span>
        </button>

        <button
          onClick={logout}
          className="w-full bg-white rounded-2xl shadow-soft p-4 flex items-center gap-3 hover:shadow-card transition-all"
        >
          <div className="w-10 h-10 rounded-xl bg-red-50 flex items-center justify-center">
            <LogOut className="w-5 h-5 text-red-500" />
          </div>
          <span className="text-sm font-semibold text-red-500 flex-1 text-left">Sair da conta</span>
        </button>
      </div>

      {/* Password Modal */}
      <Modal open={pwModal} onClose={() => setPwModal(false)} title="Alterar senha">
        <div className="space-y-3 py-2">
          <input
            type="password"
            value={currentPw}
            onChange={(e) => setCurrentPw(e.target.value)}
            placeholder="Senha atual"
            className="w-full px-4 py-3.5 rounded-2xl bg-brand-gray border-2 border-transparent focus:border-brand-blue focus:bg-white transition-all text-gray-800 placeholder-gray-400"
          />
          <input
            type="password"
            value={newPw}
            onChange={(e) => setNewPw(e.target.value)}
            placeholder="Nova senha (mín. 6 caracteres)"
            className="w-full px-4 py-3.5 rounded-2xl bg-brand-gray border-2 border-transparent focus:border-brand-blue focus:bg-white transition-all text-gray-800 placeholder-gray-400"
          />
          {pwError && (
            <div className="bg-red-50 text-red-600 text-sm rounded-xl px-3.5 py-2.5 animate-fade-in">
              {pwError}
            </div>
          )}
          <Button variant="primary" fullWidth onClick={handlePwChange} disabled={!currentPw || !newPw}>
            Confirmar alteração
          </Button>
        </div>
      </Modal>
    </div>
  );
}
