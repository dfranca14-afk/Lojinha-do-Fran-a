import { useApp } from '@/store';
import type { KitType } from '@/types';
import {
  Package,
  CheckCircle2,
  CalendarDays,
  DollarSign,
  Sprout,
  Warehouse,
  Database,
  Clock,
  ChevronRight,
  TrendingUp,
  AlertCircle,
} from 'lucide-react';

interface AdminDashboardProps {
  onNavigate: (screen: string) => void;
}

const KIT_ICONS: Record<KitType, typeof Sprout> = {
  terra: Sprout,
  celeiro: Warehouse,
  silo: Database,
};

const KIT_NAMES: Record<KitType, string> = {
  terra: 'Kit Terra',
  celeiro: 'Kit Celeiro',
  silo: 'Kit Silo',
};

export function AdminDashboard({ onNavigate }: AdminDashboardProps) {
  const { orders } = useApp();

  const today = new Date().toDateString();
  const todayOrders = orders.filter((o) => new Date(o.date).toDateString() === today);
  const pendingOrders = orders.filter((o) => o.status !== 'Recebido');
  const completedToday = todayOrders.filter((o) => o.status === 'Recebido');
  const todaySales = todayOrders.reduce((sum, o) => sum + o.total, 0);
  const activePlans = orders.filter((o) => o.plan !== '1 Kit').length;

  const kitTypes: KitType[] = ['terra', 'celeiro', 'silo'];

  return (
    <div className="p-6 space-y-6 animate-fade-in">
      <div>
        <h1 className="text-2xl font-extrabold text-gray-800">Dashboard</h1>
        <p className="text-sm text-gray-400 mt-1">Visão geral da loja</p>
      </div>

      {/* Stats grid */}
      <div className="grid grid-cols-2 gap-4">
        <div className="bg-white rounded-2xl shadow-soft p-5">
          <div className="w-10 h-10 rounded-xl bg-amber-50 flex items-center justify-center mb-3">
            <AlertCircle className="w-5 h-5 text-amber-500" />
          </div>
          <p className="text-2xl font-extrabold text-gray-800">{pendingOrders.length}</p>
          <p className="text-xs text-gray-400 mt-0.5">Pedidos aguardando</p>
        </div>

        <div className="bg-white rounded-2xl shadow-soft p-5">
          <div className="w-10 h-10 rounded-xl bg-green-50 flex items-center justify-center mb-3">
            <CheckCircle2 className="w-5 h-5 text-brand-green" />
          </div>
          <p className="text-2xl font-extrabold text-gray-800">{completedToday.length}</p>
          <p className="text-xs text-gray-400 mt-0.5">Concluídos hoje</p>
        </div>

        <div className="bg-white rounded-2xl shadow-soft p-5">
          <div className="w-10 h-10 rounded-xl bg-blue-50 flex items-center justify-center mb-3">
            <CalendarDays className="w-5 h-5 text-brand-blue" />
          </div>
          <p className="text-2xl font-extrabold text-gray-800">{activePlans}</p>
          <p className="text-xs text-gray-400 mt-0.5">Planos ativos</p>
        </div>

        <div className="bg-white rounded-2xl shadow-soft p-5">
          <div className="w-10 h-10 rounded-xl bg-green-50 flex items-center justify-center mb-3">
            <DollarSign className="w-5 h-5 text-brand-green-dark" />
          </div>
          <p className="text-2xl font-extrabold text-gray-800">
            R$ {todaySales.toFixed(2).replace('.', ',')}
          </p>
          <p className="text-xs text-gray-400 mt-0.5">Vendas do dia</p>
        </div>
      </div>

      {/* Kit cards */}
      <div>
        <h2 className="font-bold text-gray-800 text-sm mb-3">Kits</h2>
        <div className="space-y-3">
          {kitTypes.map((kitType) => {
            const Icon = KIT_ICONS[kitType];
            const kitPending = pendingOrders.filter((o) => o.kit === KIT_NAMES[kitType]).length;
            return (
              <div
                key={kitType}
                className="bg-white rounded-2xl shadow-soft p-4 flex items-center gap-4"
              >
                <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-brand-gray to-gray-100 flex items-center justify-center shrink-0">
                  <Icon className="w-6 h-6 text-gray-700" strokeWidth={2} />
                </div>
                <div className="flex-1">
                  <p className="font-semibold text-gray-800 text-sm">{KIT_NAMES[kitType]}</p>
                  <p className="text-xs text-gray-400 mt-0.5">
                    {kitPending} pedido(s) aguardando
                  </p>
                </div>
                <button
                  onClick={() => onNavigate('pedidos')}
                  className="px-4 py-2 rounded-xl bg-brand-blue text-white text-sm font-semibold hover:bg-blue-600 transition-colors flex items-center gap-1"
                >
                  Abrir
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
