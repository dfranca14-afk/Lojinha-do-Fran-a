import { useState } from 'react';
import { useApp } from '@/store';
import { Button } from '@/components/Button';
import type { Order, KitType } from '@/types';
import {
  Sprout,
  Warehouse,
  Database,
  Copy,
  Check,
  Send,
  User,
  Tag,
  Calendar,
  DollarSign,
  ShoppingBag,
} from 'lucide-react';

const KIT_ICONS: Record<KitType, typeof Sprout> = {
  terra: Sprout,
  celeiro: Warehouse,
  silo: Database,
};

const KIT_NAMES: Record<KitType, string> = {
  terra: 'Kit Terra',
  celeiro: 'Kit Celeiro',
  silo: 'Kit Silo',
};

const STATUS_STYLES: Record<string, string> = {
  'Pedido recebido': 'bg-blue-50 text-brand-blue',
  'Em processamento': 'bg-amber-50 text-amber-600',
  'Recebido': 'bg-green-50 text-brand-green-dark',
};

export function AdminOrders() {
  const { orders, sendBatchDelivery, addNotification } = useApp();
  const [copiedAll, setCopiedAll] = useState(false);
  const [copiedKit, setCopiedKit] = useState<string | null>(null);
  const [sentBatch, setSentBatch] = useState<string | null>(null);

  const kitTypes: KitType[] = ['terra', 'celeiro', 'silo'];

  function copyAllTags() {
    const allTags = orders.flatMap((o) => o.tags || []);
    navigator.clipboard.writeText(allTags.join('\n')).catch(() => {});
    setCopiedAll(true);
    setTimeout(() => setCopiedAll(false), 2000);
  }

  function copyKitTags(kitName: string) {
    const kitTags = orders
      .filter((o) => o.kit === kitName)
      .flatMap((o) => o.tags || []);
    navigator.clipboard.writeText(kitTags.join('\n')).catch(() => {});
    setCopiedKit(kitName);
    setTimeout(() => setCopiedKit(null), 2000);
  }

  function handleSendDelivery(kitName: string, kitOrders: Order[]) {
    const orderIds = kitOrders.map((o) => o.id);
    sendBatchDelivery(orderIds);
    setSentBatch(kitName);
    setTimeout(() => setSentBatch(null), 2000);

    // Notify all customers in the batch
    kitOrders.forEach((order) => {
      addNotification({
        title: 'Entrega enviada!',
        message: `Seu pedido de ${order.kit} foi entregue. Confira no histórico.`,
        orderId: order.id,
      });
    });
  }

  return (
    <div className="p-6 space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-extrabold text-gray-800">Pedidos</h1>
          <p className="text-sm text-gray-400 mt-1">Gerenciamento por kit</p>
        </div>
        <Button variant="secondary" onClick={copyAllTags}>
          {copiedAll ? (
            <>
              <Check className="w-4 h-4" />
              Copiado!
            </>
          ) : (
            <>
              <Copy className="w-4 h-4" />
              Copiar todas as tags
            </>
          )}
        </Button>
      </div>

      {orders.length === 0 ? (
        <div className="bg-white rounded-2xl shadow-soft p-8 text-center">
          <ShoppingBag className="w-12 h-12 text-gray-300 mx-auto mb-3" />
          <p className="text-sm text-gray-400">Nenhum pedido ainda.</p>
        </div>
      ) : (
        <div className="space-y-6">
          {kitTypes.map((kitType) => {
            const kitName = KIT_NAMES[kitType];
            const kitOrders = orders.filter((o) => o.kit === kitName);
            const Icon = KIT_ICONS[kitType];
            const pendingOrders = kitOrders.filter((o) => o.status !== 'Recebido');

            if (kitOrders.length === 0) return null;

            return (
              <div key={kitType} className="bg-white rounded-2xl shadow-soft overflow-hidden">
                {/* Kit header */}
                <div className="bg-gradient-to-r from-brand-gray to-gray-50 px-5 py-4 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-white flex items-center justify-center">
                      <Icon className="w-5 h-5 text-gray-700" />
                    </div>
                    <div>
                      <h3 className="font-bold text-gray-800 text-sm">{kitName}</h3>
                      <p className="text-xs text-gray-400">
                        {kitOrders.length} pedido(s) — {pendingOrders.length} aguardando
                      </p>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={() => copyKitTags(kitName)}
                      className="px-3 py-2 rounded-lg bg-white text-xs font-semibold text-gray-600 hover:bg-blue-50 hover:text-brand-blue transition-colors flex items-center gap-1"
                    >
                      {copiedKit === kitName ? (
                        <>
                          <Check className="w-3.5 h-3.5" />
                          Copiado!
                        </>
                      ) : (
                        <>
                          <Copy className="w-3.5 h-3.5" />
                          Copiar tags
                        </>
                      )}
                    </button>
                    {pendingOrders.length > 0 && (
                      <button
                        onClick={() => handleSendDelivery(kitName, pendingOrders)}
                        className="px-3 py-2 rounded-lg bg-brand-green text-white text-xs font-semibold hover:bg-brand-green-dark transition-colors flex items-center gap-1"
                      >
                        {sentBatch === kitName ? (
                          <>
                            <Check className="w-3.5 h-3.5" />
                            Enviado!
                          </>
                        ) : (
                          <>
                            <Send className="w-3.5 h-3.5" />
                            Enviar Entrega
                          </>
                        )}
                      </button>
                    )}
                  </div>
                </div>

                {/* Orders list */}
                <div className="divide-y divide-gray-50">
                  {kitOrders.map((order) => (
                    <div key={order.id} className="p-4">
                      <div className="flex items-start justify-between mb-3">
                        <div className="flex items-center gap-2">
                          <div className="w-8 h-8 rounded-lg bg-blue-50 flex items-center justify-center">
                            <User className="w-4 h-4 text-brand-blue" />
                          </div>
                          <div>
                            <p className="font-semibold text-gray-800 text-sm">{order.userName}</p>
                            <p className="text-xs text-gray-400">{order.userEmail}</p>
                          </div>
                        </div>
                        <span className={`text-xs font-semibold px-2.5 py-1 rounded-full ${STATUS_STYLES[order.status]}`}>
                          {order.status}
                        </span>
                      </div>

                      <div className="grid grid-cols-2 gap-2 text-xs text-gray-500 mb-2">
                        <div className="flex items-center gap-1.5">
                          <ShoppingBag className="w-3.5 h-3.5" />
                          {order.plan}
                        </div>
                        <div className="flex items-center gap-1.5">
                          <Tag className="w-3.5 h-3.5" />
                          {order.tagCount} tag(s)
                        </div>
                        <div className="flex items-center gap-1.5">
                          <DollarSign className="w-3.5 h-3.5" />
                          R$ {order.total.toFixed(2).replace('.', ',')}
                        </div>
                        <div className="flex items-center gap-1.5">
                          <Calendar className="w-3.5 h-3.5" />
                          {new Date(order.date).toLocaleDateString('pt-BR')}
                        </div>
                      </div>

                      {order.tags && order.tags.length > 0 && (
                        <div className="flex flex-wrap gap-1.5 mt-2">
                          {order.tags.map((tag, i) => (
                            <span
                              key={i}
                              className="px-2 py-1 rounded-lg bg-gray-100 text-xs font-mono text-gray-600"
                            >
                              {tag}
                            </span>
                          ))}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
