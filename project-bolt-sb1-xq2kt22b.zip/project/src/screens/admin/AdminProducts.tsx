import { useState, useRef, type ChangeEvent } from 'react';
import { useApp } from '@/store';
import { Button } from '@/components/Button';
import type { ProductConfig } from '@/types';
import {
  Package,
  Save,
  Image as ImageIcon,
  Trash2,
  Check,
  Upload,
  Eye,
} from 'lucide-react';

export function AdminProducts() {
  const { products, updateProduct, updateProductIcon, removeProductIcon } = useApp();
  const [editing, setEditing] = useState<string | null>(null);
  const [editData, setEditData] = useState<ProductConfig | null>(null);
  const [saved, setSaved] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  function startEdit(product: ProductConfig) {
    setEditing(product.id);
    setEditData({ ...product });
    setSaved(false);
  }

  function handleSave() {
    if (!editData) return;
    updateProduct(editData.id, {
      name: editData.name,
      description: editData.description,
      price: editData.price,
      status: editData.status,
      order: editData.order,
    });
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  }

  function handleImageUpload(e: ChangeEvent<HTMLInputElement>, productId: string) {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!['image/png', 'image/jpeg', 'image/webp'].includes(file.type)) {
      alert('Formato não suportado. Use PNG, JPG ou WEBP.');
      return;
    }
    const reader = new FileReader();
    reader.onload = (ev) => {
      const img = new Image();
      img.onload = () => {
        const size = 256;
        const canvas = document.createElement('canvas');
        canvas.width = size;
        canvas.height = size;
        const ctx = canvas.getContext('2d');
        if (!ctx) return;
        const minDim = Math.min(img.width, img.height);
        const sx = (img.width - minDim) / 2;
        const sy = (img.height - minDim) / 2;
        ctx.drawImage(img, sx, sy, minDim, minDim, 0, 0, size, size);
        const dataUrl = canvas.toDataURL('image/jpeg', 0.85);
        updateProductIcon(productId, dataUrl);
      };
      img.src = ev.target?.result as string;
    };
    reader.readAsDataURL(file);
  }

  return (
    <div className="p-6 space-y-6 animate-fade-in">
      <div>
        <h1 className="text-2xl font-extrabold text-gray-800">Produtos</h1>
        <p className="text-sm text-gray-400 mt-1">Gerencie os kits da loja</p>
      </div>

      <div className="space-y-4">
        {products.map((product) => {
          const isEditing = editing === product.id;
          const data = isEditing && editData ? editData : product;
          return (
            <div key={product.id} className="bg-white rounded-2xl shadow-soft p-5">
              {/* Preview + icon management */}
              <div className="flex items-start gap-4 mb-4">
                <div className="w-20 h-20 rounded-2xl bg-brand-gray flex items-center justify-center overflow-hidden shrink-0">
                  {product.iconData ? (
                    <img src={product.iconData} alt={product.name} className="w-full h-full object-cover" />
                  ) : (
                    <Package className="w-8 h-8 text-gray-300" />
                  )}
                </div>
                <div className="flex-1">
                  <p className="font-semibold text-gray-800 text-sm">{product.name}</p>
                  <p className="text-xs text-gray-400 mt-0.5">{product.description}</p>
                  <div className="flex gap-2 mt-3">
                    <button
                      onClick={() => fileRef.current?.click()}
                      className="px-3 py-1.5 rounded-lg bg-blue-50 text-brand-blue text-xs font-semibold hover:bg-blue-100 transition-colors flex items-center gap-1"
                    >
                      <ImageIcon className="w-3.5 h-3.5" />
                      Trocar Ícone
                    </button>
                    {product.iconData && (
                      <button
                        onClick={() => removeProductIcon(product.id)}
                        className="px-3 py-1.5 rounded-lg bg-red-50 text-red-500 text-xs font-semibold hover:bg-red-100 transition-colors flex items-center gap-1"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        Remover
                      </button>
                    )}
                  </div>
                  <input
                    ref={fileRef}
                    type="file"
                    accept="image/png,image/jpeg,image/webp"
                    className="hidden"
                    onChange={(e) => handleImageUpload(e, product.id)}
                  />
                </div>
              </div>

              {/* Edit fields */}
              <div className="space-y-3">
                <div>
                  <label className="block text-xs font-medium text-gray-500 mb-1">Nome</label>
                  <input
                    type="text"
                    value={data.name}
                    onChange={(e) => isEditing && setEditData({ ...editData!, name: e.target.value })}
                    readOnly={!isEditing}
                    className={`w-full px-3 py-2.5 rounded-xl border-2 transition-all text-sm ${
                      isEditing
                        ? 'bg-brand-gray border-transparent focus:border-brand-blue focus:bg-white text-gray-800'
                        : 'bg-gray-50 border-transparent text-gray-600'
                    }`}
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-gray-500 mb-1">Descrição</label>
                  <input
                    type="text"
                    value={data.description}
                    onChange={(e) => isEditing && setEditData({ ...editData!, description: e.target.value })}
                    readOnly={!isEditing}
                    className={`w-full px-3 py-2.5 rounded-xl border-2 transition-all text-sm ${
                      isEditing
                        ? 'bg-brand-gray border-transparent focus:border-brand-blue focus:bg-white text-gray-800'
                        : 'bg-gray-50 border-transparent text-gray-600'
                    }`}
                  />
                </div>

                <div className="grid grid-cols-3 gap-3">
                  <div>
                    <label className="block text-xs font-medium text-gray-500 mb-1">Preço</label>
                    <input
                      type="number"
                      step="0.01"
                      value={data.price}
                      onChange={(e) => isEditing && setEditData({ ...editData!, price: parseFloat(e.target.value) || 0 })}
                      readOnly={!isEditing}
                      className={`w-full px-3 py-2.5 rounded-xl border-2 transition-all text-sm ${
                        isEditing
                          ? 'bg-brand-gray border-transparent focus:border-brand-blue focus:bg-white text-gray-800'
                          : 'bg-gray-50 border-transparent text-gray-600'
                      }`}
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-gray-500 mb-1">Ordem</label>
                    <input
                      type="number"
                      value={data.order}
                      onChange={(e) => isEditing && setEditData({ ...editData!, order: parseInt(e.target.value) || 0 })}
                      readOnly={!isEditing}
                      className={`w-full px-3 py-2.5 rounded-xl border-2 transition-all text-sm ${
                        isEditing
                          ? 'bg-brand-gray border-transparent focus:border-brand-blue focus:bg-white text-gray-800'
                          : 'bg-gray-50 border-transparent text-gray-600'
                      }`}
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-gray-500 mb-1">Status</label>
                    <select
                      value={data.status}
                      onChange={(e) => isEditing && setEditData({ ...editData!, status: e.target.value as 'ativo' | 'inativo' })}
                      disabled={!isEditing}
                      className={`w-full px-3 py-2.5 rounded-xl border-2 transition-all text-sm ${
                        isEditing
                          ? 'bg-brand-gray border-transparent focus:border-brand-blue focus:bg-white text-gray-800'
                          : 'bg-gray-50 border-transparent text-gray-600'
                      }`}
                    >
                      <option value="ativo">Ativo</option>
                      <option value="inativo">Inativo</option>
                    </select>
                  </div>
                </div>

                {/* Action buttons */}
                <div className="flex gap-2 pt-2">
                  {!isEditing ? (
                    <Button variant="secondary" fullWidth onClick={() => startEdit(product)}>
                      Editar
                    </Button>
                  ) : (
                    <>
                      <Button
                        variant={saved ? 'green' : 'primary'}
                        fullWidth
                        onClick={handleSave}
                      >
                        {saved ? (
                          <>
                            <Check className="w-4 h-4" />
                            Salvo!
                          </>
                        ) : (
                          <>
                            <Save className="w-4 h-4" />
                            Salvar
                          </>
                        )}
                      </Button>
                      <Button
                        variant="secondary"
                        onClick={() => {
                          setEditing(null);
                          setEditData(null);
                        }}
                      >
                        Cancelar
                      </Button>
                    </>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
