import { useState } from 'react';
import { useApp } from '@/store';
import { Button } from '@/components/Button';
import type { KitType } from '@/types';
import { Clock, Save, Check, Sprout, Warehouse, Database } from 'lucide-react';

const KIT_ICONS: Record<KitType, typeof Sprout> = {
  terra: Sprout,
  celeiro: Warehouse,
  silo: Database,
};

const KIT_NAMES: Record<KitType, string> = {
  terra: 'Kit Terra',
  celeiro: 'Kit Celeiro',
  silo: 'Kit Silo',
};

export function AdminSchedules() {
  const { deliveryTimes, updateDeliveryTime } = useApp();
  const [times, setTimes] = useState<Record<KitType, string>>(deliveryTimes);
  const [savedKit, setSavedKit] = useState<string | null>(null);

  const kitTypes: KitType[] = ['terra', 'celeiro', 'silo'];

  function handleSave(kit: KitType) {
    updateDeliveryTime(kit, times[kit]);
    setSavedKit(kit);
    setTimeout(() => setSavedKit(null), 2000);
  }

  return (
    <div className="p-6 space-y-6 animate-fade-in">
      <div>
        <h1 className="text-2xl font-extrabold text-gray-800">Horários de Entrega</h1>
        <p className="text-sm text-gray-400 mt-1">
          Apenas para o plano 1 Kit. Planos de 7 e 30 dias não têm horário configurável.
        </p>
      </div>

      {/* Info banner */}
      <div className="bg-blue-50 border border-blue-100 rounded-2xl p-4 flex items-start gap-3">
        <Clock className="w-5 h-5 text-brand-blue shrink-0 mt-0.5" />
        <div>
          <p className="text-sm font-semibold text-gray-700">Regra oficial</p>
          <p className="text-xs text-gray-500 mt-1 leading-relaxed">
            O horário configurado aqui aparece no relógio que os clientes veem ao lado do kit selecionado.
            Planos de 7 e 30 dias não mostram relógio.
          </p>
        </div>
      </div>

      {/* Kit schedule editors */}
      <div className="space-y-4">
        {kitTypes.map((kit) => {
          const Icon = KIT_ICONS[kit];
          const isSaved = savedKit === kit;
          return (
            <div key={kit} className="bg-white rounded-2xl shadow-soft p-5">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 rounded-xl bg-brand-gray flex items-center justify-center">
                  <Icon className="w-5 h-5 text-gray-700" />
                </div>
                <h3 className="font-semibold text-gray-800 text-sm">{KIT_NAMES[kit]}</h3>
              </div>

              <label className="block text-xs font-medium text-gray-500 mb-1.5">
                Tempo de entrega
              </label>
              <input
                type="text"
                value={times[kit]}
                onChange={(e) => setTimes({ ...times, [kit]: e.target.value })}
                placeholder="Ex: daqui 15 minutos, em até 1 hora, 22:00"
                className="w-full px-4 py-3 rounded-2xl bg-brand-gray border-2 border-transparent focus:border-brand-blue focus:bg-white transition-all text-gray-800 text-sm placeholder-gray-400"
              />

              <div className="mt-2 flex flex-wrap gap-2">
                {['daqui 15 minutos', 'daqui 20 minutos', 'em até 1 hora', '22:00'].map((suggestion) => (
                  <button
                    key={suggestion}
                    onClick={() => setTimes({ ...times, [kit]: suggestion })}
                    className="px-3 py-1.5 rounded-lg bg-gray-100 hover:bg-blue-50 hover:text-brand-blue text-xs text-gray-500 transition-colors"
                  >
                    {suggestion}
                  </button>
                ))}
              </div>

              <Button
                variant={isSaved ? 'green' : 'primary'}
                fullWidth
                className="mt-4"
                onClick={() => handleSave(kit)}
              >
                {isSaved ? (
                  <>
                    <Check className="w-4 h-4" />
                    Salvo!
                  </>
                ) : (
                  <>
                    <Save className="w-4 h-4" />
                    Salvar horário
                  </>
                )}
              </Button>
            </div>
          );
        })}
      </div>
    </div>
  );
}
