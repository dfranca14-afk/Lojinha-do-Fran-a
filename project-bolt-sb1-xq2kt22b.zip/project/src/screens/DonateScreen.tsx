import { useState } from 'react';
import { Button } from '@/components/Button';
import { Modal } from '@/components/Modal';
import { Heart, Copy, Check } from 'lucide-react';

const QUICK_VALUES = [2, 5, 10, 20];

export function DonateScreen() {
  const [selected, setSelected] = useState<number | null>(null);
  const [copied, setCopied] = useState(false);
  const [modal, setModal] = useState(false);

  const pixCode = '00020126360014BR.GOV.BCB.PIX0114+5511999999999520400005303986540' + (selected || 0).toFixed(2) + '5802BR5913LojinhaFranca6009SAOPAULO62070503***6304A1B2';

  function handleCopy() {
    navigator.clipboard.writeText(pixCode).catch(() => {});
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }

  function handleGenerate() {
    if (selected === null) return;
    setModal(true);
  }

  return (
    <div className="px-4 py-5 space-y-5 animate-fade-in">
      {/* Header card */}
      <div className="bg-gradient-to-br from-rose-400 to-brand-gold rounded-3xl shadow-card p-6 text-white text-center">
        <div className="w-16 h-16 mx-auto rounded-2xl bg-white/20 flex items-center justify-center mb-3">
          <Heart className="w-8 h-8" fill="white" />
        </div>
        <h2 className="text-xl font-bold">Apoie a Lojinha</h2>
        <p className="text-sm text-white/80 mt-1">
          Sua contribuição ajuda a manter o projeto e melhorar o atendimento.
        </p>
      </div>

      {/* Quick values */}
      <div>
        <h3 className="font-bold text-gray-800 text-sm mb-3">Escolha um valor</h3>
        <div className="grid grid-cols-4 gap-2">
          {QUICK_VALUES.map((v) => (
            <button
              key={v}
              onClick={() => setSelected(v)}
              className={`
                py-4 rounded-2xl border-2 transition-all font-bold text-sm
                ${selected === v
                  ? 'border-brand-gold bg-yellow-50 text-amber-700 scale-[1.03]'
                  : 'border-gray-100 bg-white text-gray-600 hover:border-gray-200'
                }
              `}
            >
              R${v}
            </button>
          ))}
        </div>
      </div>

      <Button variant="green" fullWidth disabled={selected === null} onClick={handleGenerate}>
        <Heart className="w-5 h-5" />
        Gerar PIX
      </Button>

      {/* PIX Modal */}
      <Modal open={modal} onClose={() => setModal(false)} title="PIX Gerado">
        <div className="py-2">
          <p className="text-sm text-gray-500 mb-2">Valor</p>
          <p className="text-2xl font-extrabold text-gray-800 mb-4">
            R$ {(selected || 0).toFixed(2).replace('.', ',')}
          </p>
          <p className="text-sm text-gray-500 mb-2">Código PIX</p>
          <div className="bg-brand-gray rounded-2xl p-3 mb-4">
            <p className="text-xs font-mono text-gray-600 break-all leading-relaxed">
              {pixCode}
            </p>
          </div>
          <Button
            variant={copied ? 'green' : 'primary'}
            fullWidth
            onClick={handleCopy}
          >
            {copied ? (
              <>
                <Check className="w-5 h-5" />
                Copiado!
              </>
            ) : (
              <>
                <Copy className="w-5 h-5" />
                Copiar código
              </>
            )}
          </Button>
        </div>
      </Modal>
    </div>
  );
}
