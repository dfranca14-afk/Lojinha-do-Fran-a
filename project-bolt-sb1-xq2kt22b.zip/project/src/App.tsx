import { useState, useEffect } from 'react';
import { AppProvider, useApp } from '@/store';
import { AppShell } from '@/components/AppShell';
import { AuthScreen } from '@/screens/AuthScreen';
import { Home } from '@/screens/Home';
import { BalanceScreen } from '@/screens/BalanceScreen';
import { AccountScreen } from '@/screens/AccountScreen';
import { HistoryScreen } from '@/screens/HistoryScreen';
import { ChatScreen } from '@/screens/ChatScreen';
import { DonateScreen } from '@/screens/DonateScreen';
import { UtilitiesScreen } from '@/screens/UtilitiesScreen';
import { TutorialsScreen } from '@/screens/TutorialsScreen';
import { ProductsScreen } from '@/screens/ProductsScreen';
import type { ScreenName } from '@/types';
import { MessageCircle, Send, Music } from 'lucide-react';

import { AdminShell } from '@/components/AdminShell';
import { AdminLogin } from '@/screens/admin/AdminLogin';
import { AdminDashboard } from '@/screens/admin/AdminDashboard';
import { AdminProducts } from '@/screens/admin/AdminProducts';
import { AdminSchedules } from '@/screens/admin/AdminSchedules';
import { AdminOrders } from '@/screens/admin/AdminOrders';

function Footer() {
  return (
    <footer className="mt-6 px-4 pb-6">
      <div className="bg-white rounded-3xl shadow-soft p-5">
        <p className="text-center text-xs text-gray-400 mb-4">
          Lojinha do França — Sua fazenda, mais leve.
        </p>
        <div className="flex justify-center gap-4">
          <a
            href="#"
            onClick={(e) => e.preventDefault()}
            className="w-11 h-11 rounded-2xl bg-green-50 flex items-center justify-center hover:bg-green-100 transition-colors"
            aria-label="WhatsApp"
          >
            <MessageCircle className="w-5 h-5 text-brand-green" />
          </a>
          <a
            href="#"
            onClick={(e) => e.preventDefault()}
            className="w-11 h-11 rounded-2xl bg-blue-50 flex items-center justify-center hover:bg-blue-100 transition-colors"
            aria-label="Telegram"
          >
            <Send className="w-5 h-5 text-brand-blue" />
          </a>
          <a
            href="#"
            onClick={(e) => e.preventDefault()}
            className="w-11 h-11 rounded-2xl bg-gray-100 flex items-center justify-center hover:bg-gray-200 transition-colors"
            aria-label="TikTok"
          >
            <Music className="w-5 h-5 text-gray-700" />
          </a>
        </div>
      </div>
    </footer>
  );
}

function AdminApp() {
  const { admin } = useApp();
  const [screen, setScreen] = useState('dashboard');

  if (!admin) {
    return <AdminLogin onSuccess={() => {}} />;
  }

  function renderScreen() {
    switch (screen) {
      case 'dashboard':
        return <AdminDashboard onNavigate={setScreen} />;
      case 'pedidos':
        return <AdminOrders />;
      case 'produtos':
        return <AdminProducts />;
      case 'horarios':
        return <AdminSchedules />;
      default:
        return <AdminDashboard onNavigate={setScreen} />;
    }
  }

  return (
    <AdminShell currentScreen={screen} onNavigate={setScreen} onExit={() => {}}>
      {renderScreen()}
    </AdminShell>
  );
}

function AppContent() {
  const { user } = useApp();
  const [screen, setScreen] = useState<ScreenName>('home');
  const [isAdmin, setIsAdmin] = useState(false);

  // Hash-based routing for /admin
  useEffect(() => {
    function checkHash() {
      const hash = window.location.hash.toLowerCase();
      setIsAdmin(hash.startsWith('#/admin') || hash.startsWith('admin'));
    }
    checkHash();
    window.addEventListener('hashchange', checkHash);
    return () => window.removeEventListener('hashchange', checkHash);
  }, []);

  if (isAdmin) {
    return <AdminApp />;
  }

  if (!user) {
    return <AuthScreen onSuccess={() => {}} />;
  }

  function renderScreen() {
    switch (screen) {
      case 'home':
        return <Home onNavigate={(s) => setScreen(s)} />;
      case 'balance':
        return <BalanceScreen />;
      case 'account':
        return <AccountScreen onNavigate={(s) => setScreen(s)} />;
      case 'history':
        return <HistoryScreen />;
      case 'chat':
      case 'support':
        return <ChatScreen />;
      case 'donate':
        return <DonateScreen />;
      case 'utilities':
        return <UtilitiesScreen />;
      case 'tutorials':
        return <TutorialsScreen />;
      case 'products':
        return <ProductsScreen />;
      case 'notifications':
        return <Home onNavigate={(s) => setScreen(s)} />;
      default:
        return <Home onNavigate={(s) => setScreen(s)} />;
    }
  }

  return (
    <AppShell currentScreen={screen} onNavigate={setScreen}>
      {renderScreen()}
      <Footer />
    </AppShell>
  );
}

function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}

export default App;
