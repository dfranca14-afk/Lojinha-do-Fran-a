export type ScreenName =
  | 'home'
  | 'balance'
  | 'account'
  | 'products'
  | 'chat'
  | 'support'
  | 'history'
  | 'tutorials'
  | 'utilities'
  | 'donate'
  | 'notifications'
  | 'plans'
  | 'como-coletar';

export interface User {
  id: string;
  name: string;
  email: string;
  password: string;
  createdAt: string;
}

export interface Order {
  id: string;
  kit: string;
  plan: string;
  tagCount: number;
  total: number;
  date: string;
  status: OrderStatus;
  tags: string[];
  userEmail: string;
  userName: string;
}

export type OrderStatus = 'Pedido recebido' | 'Em processamento' | 'Recebido';

export interface Notification {
  id: string;
  title: string;
  message: string;
  date: string;
  read: boolean;
  orderId?: string;
}

export interface BalanceTransaction {
  id: string;
  type: 'deposit' | 'purchase';
  description: string;
  amount: number;
  date: string;
}

export interface ChatMessage {
  id: string;
  text: string;
  sender: 'user' | 'support';
  timestamp: string;
}

export type KitType = 'terra' | 'celeiro' | 'silo';

export type PlanType = '1kit' | '7dias' | '30dias';

export interface KitInfo {
  id: KitType;
  name: string;
  icon: string;
  color: string;
  bgColor: string;
  deliveryTime: string;
}

export interface ProductCategory {
  id: string;
  name: string;
  icon: string;
  color: string;
  description: string;
}

export interface AdminUser {
  id: string;
  email: string;
  password: string;
}

export interface ProductConfig {
  id: string;
  name: string;
  description: string;
  price: number;
  status: 'ativo' | 'inativo';
  order: number;
  iconData?: string;
}

export interface PlanSubscription {
  id: string;
  plan: PlanType;
  kit: KitType;
  startDate: string;
  endDate: string;
  kitsDelivered: number;
  totalKits: number;
  nextDelivery: string;
}

export const KITS: KitInfo[] = [
  {
    id: 'terra',
    name: 'Kit Terra',
    icon: 'Sprout',
    color: 'text-brand-green-dark',
    bgColor: 'from-green-100 to-green-50',
    deliveryTime: 'daqui 15 minutos',
  },
  {
    id: 'celeiro',
    name: 'Kit Celeiro',
    icon: 'Warehouse',
    color: 'text-amber-700',
    bgColor: 'from-amber-100 to-amber-50',
    deliveryTime: 'daqui 20 minutos',
  },
  {
    id: 'silo',
    name: 'Kit Silo',
    icon: 'Database',
    color: 'text-brand-blue',
    bgColor: 'from-blue-100 to-blue-50',
    deliveryTime: 'daqui 10 minutos',
  },
];

export const PLANS: { id: PlanType; label: string }[] = [
  { id: '1kit', label: '1 Kit' },
  { id: '7dias', label: '7 Dias' },
  { id: '30dias', label: '30 Dias' },
];

export const PLAN_PRICES: Record<PlanType, number> = {
  '1kit': 23.8,
  '7dias': 89.9,
  '30dias': 249.9,
};

export const PLAN_TOTAL_KITS: Record<PlanType, number> = {
  '1kit': 1,
  '7dias': 7,
  '30dias': 30,
};

export const PRODUCT_CATEGORIES: ProductCategory[] = [
  {
    id: 'materiais',
    name: 'Materiais',
    icon: 'Hammer',
    color: 'from-orange-400 to-orange-500',
    description: 'Madeira, pregos, tijolos e mais',
  },
  {
    id: 'producoes',
    name: 'Produções',
    icon: 'Wheat',
    color: 'from-yellow-400 to-amber-500',
    description: 'Itens processados da fazenda',
  },
  {
    id: 'passe-rural',
    name: 'Passe Rural',
    icon: 'Scroll',
    color: 'from-green-400 to-green-600',
    description: 'Recompensas exclusivas da temporada',
  },
  {
    id: 'diamantes',
    name: 'Diamantes',
    icon: 'Gem',
    color: 'from-cyan-400 to-blue-500',
    description: 'Moeda premium do jogo',
  },
  {
    id: 'fazendas',
    name: 'Fazendas',
    icon: 'Tractor',
    color: 'from-lime-400 to-green-500',
    description: 'Fazendas premium prontas',
  },
];

export const BANNER_SLIDES = [
  {
    title: 'Kit Terra',
    subtitle: 'Materiais de expansão',
    gradient: 'from-green-500 via-green-400 to-emerald-400',
    icon: 'Sprout',
  },
  {
    title: 'Produções',
    subtitle: 'Itens processados premium',
    gradient: 'from-amber-500 via-yellow-400 to-orange-400',
    icon: 'Wheat',
  },
  {
    title: 'Passe Rural',
    subtitle: 'Recompensas da temporada',
    gradient: 'from-blue-500 via-brand-blue to-brand-blue-light',
    icon: 'Scroll',
  },
  {
    title: 'Fazendas Premium',
    subtitle: 'Fazendas completas e prontas',
    gradient: 'from-lime-500 via-green-500 to-emerald-500',
    icon: 'Tractor',
  },
];

export const MENU_ITEMS = [
  { id: 'home', label: 'Início', icon: 'Home' },
  { id: 'balance', label: 'Meu Saldo', icon: 'Wallet' },
  { id: 'account', label: 'Minha Conta', icon: 'UserCircle' },
  { id: 'products', label: 'Produtos', icon: 'Package' },
  { id: 'chat', label: 'Chat/Suporte', icon: 'MessageCircle' },
  { id: 'donate', label: 'Apoie a Lojinha', icon: 'Heart' },
  { id: 'history', label: 'Histórico de Compras', icon: 'Receipt' },
  { id: 'tutorials', label: 'Tutoriais', icon: 'GraduationCap' },
  { id: 'utilities', label: 'Utilidades', icon: 'Calculator' },
  { id: 'logout', label: 'Sair', icon: 'LogOut' },
] as const;

export const ADMIN_MENU_ITEMS = [
  { id: 'dashboard', label: 'Dashboard', icon: 'LayoutDashboard' },
  { id: 'pedidos', label: 'Pedidos', icon: 'ShoppingBag' },
  { id: 'produtos', label: 'Produtos', icon: 'Package' },
  { id: 'horarios', label: 'Horários de Entrega', icon: 'Clock' },
] as const;

export const DEFAULT_PRODUCTS: ProductConfig[] = [
  { id: 'terra', name: 'Kit Terra', description: 'Materiais de expansão de terra', price: 23.8, status: 'ativo', order: 1 },
  { id: 'celeiro', name: 'Kit Celeiro', description: 'Itens para o celeiro', price: 23.8, status: 'ativo', order: 2 },
  { id: 'silo', name: 'Kit Silo', description: 'Itens para o silo', price: 23.8, status: 'ativo', order: 3 },
];

export const DEFAULT_DELIVERY_TIMES: Record<KitType, string> = {
  terra: 'daqui 15 minutos',
  celeiro: 'daqui 20 minutos',
  silo: 'daqui 10 minutos',
};
