import {
  createContext,
  useContext,
  useState,
  useEffect,
  useCallback,
  type ReactNode,
} from 'react';
import type {
  User,
  Order,
  Notification,
  BalanceTransaction,
  ChatMessage,
  AdminUser,
  ProductConfig,
  PlanSubscription,
  KitType,
} from '@/types';
import {
  DEFAULT_PRODUCTS,
  DEFAULT_DELIVERY_TIMES,
} from '@/types';

const STORAGE_KEYS = {
  users: 'lf_users',
  currentUser: 'lf_current_user',
  orders: 'lf_orders',
  notifications: 'lf_notifications',
  balance: 'lf_balance',
  transactions: 'lf_transactions',
  chat: 'lf_chat',
  adminUser: 'lf_admin_user',
  products: 'lf_products',
  deliveryTimes: 'lf_delivery_times',
  subscriptions: 'lf_subscriptions',
};

function load<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

function save<T>(key: string, value: T): void {
  localStorage.setItem(key, JSON.stringify(value));
}

function uid(): string {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
}

interface AppContextValue {
  user: User | null;
  login: (email: string, password: string) => { ok: boolean; error?: string };
  signup: (name: string, email: string, password: string) => { ok: boolean; error?: string };
  logout: () => void;
  updateName: (name: string) => void;
  updatePassword: (current: string, next: string) => { ok: boolean; error?: string };

  balance: number;
  addBalance: (amount: number) => void;
  transactions: BalanceTransaction[];
  purchaseWithBalance: (total: number) => { ok: boolean; error?: string };

  orders: Order[];
  addOrder: (order: Omit<Order, 'id' | 'date' | 'status'>) => Order;
  updateOrderStatus: (orderId: string, status: Order['status']) => void;
  sendBatchDelivery: (orderIds: string[]) => void;

  notifications: Notification[];
  unreadCount: number;
  markNotificationsRead: () => void;
  addNotification: (n: Omit<Notification, 'id' | 'date' | 'read'>) => void;

  chatMessages: ChatMessage[];
  sendChatMessage: (text: string) => void;

  admin: AdminUser | null;
  adminLogin: (email: string, password: string) => { ok: boolean; error?: string };
  adminLogout: () => void;

  products: ProductConfig[];
  updateProduct: (id: string, updates: Partial<ProductConfig>) => void;
  updateProductIcon: (id: string, iconData: string) => void;
  removeProductIcon: (id: string) => void;

  deliveryTimes: Record<KitType, string>;
  updateDeliveryTime: (kit: KitType, time: string) => void;

  subscriptions: PlanSubscription[];
  addSubscription: (sub: Omit<PlanSubscription, 'id'>) => PlanSubscription;
  incrementSubscriptionDelivery: (subId: string) => void;
}

const AppContext = createContext<AppContextValue | null>(null);

export function useApp(): AppContextValue {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used within AppProvider');
  return ctx;
}

const DEFAULT_ADMIN: AdminUser = {
  id: 'admin',
  email: 'admin@lojinhafranca.com',
  password: 'admin123',
};

export function AppProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(() => load<User | null>(STORAGE_KEYS.currentUser, null));
  const [orders, setOrders] = useState<Order[]>(() => load<Order[]>(STORAGE_KEYS.orders, []));
  const [notifications, setNotifications] = useState<Notification[]>(() =>
    load<Notification[]>(STORAGE_KEYS.notifications, [])
  );
  const [balance, setBalance] = useState<number>(() => load<number>(STORAGE_KEYS.balance, 0));
  const [transactions, setTransactions] = useState<BalanceTransaction[]>(() =>
    load<BalanceTransaction[]>(STORAGE_KEYS.transactions, [])
  );
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>(() =>
    load<ChatMessage[]>(STORAGE_KEYS.chat, [
      {
        id: uid(),
        text: 'Olá! Como podemos ajudar?',
        sender: 'support',
        timestamp: new Date().toISOString(),
      },
    ])
  );
  const [admin, setAdmin] = useState<AdminUser | null>(() => load<AdminUser | null>(STORAGE_KEYS.adminUser, null));
  const [products, setProducts] = useState<ProductConfig[]>(() =>
    load<ProductConfig[]>(STORAGE_KEYS.products, DEFAULT_PRODUCTS)
  );
  const [deliveryTimes, setDeliveryTimes] = useState<Record<KitType, string>>(() =>
    load<Record<KitType, string>>(STORAGE_KEYS.deliveryTimes, DEFAULT_DELIVERY_TIMES)
  );
  const [subscriptions, setSubscriptions] = useState<PlanSubscription[]>(() =>
    load<PlanSubscription[]>(STORAGE_KEYS.subscriptions, [])
  );

  useEffect(() => save(STORAGE_KEYS.currentUser, user), [user]);
  useEffect(() => save(STORAGE_KEYS.orders, orders), [orders]);
  useEffect(() => save(STORAGE_KEYS.notifications, notifications), [notifications]);
  useEffect(() => save(STORAGE_KEYS.balance, balance), [balance]);
  useEffect(() => save(STORAGE_KEYS.transactions, transactions), [transactions]);
  useEffect(() => save(STORAGE_KEYS.chat, chatMessages), [chatMessages]);
  useEffect(() => save(STORAGE_KEYS.adminUser, admin), [admin]);
  useEffect(() => save(STORAGE_KEYS.products, products), [products]);
  useEffect(() => save(STORAGE_KEYS.deliveryTimes, deliveryTimes), [deliveryTimes]);
  useEffect(() => save(STORAGE_KEYS.subscriptions, subscriptions), [subscriptions]);

  const login = useCallback((email: string, password: string) => {
    const users = load<User[]>(STORAGE_KEYS.users, []);
    const found = users.find(
      (u) => u.email.toLowerCase() === email.toLowerCase() && u.password === password
    );
    if (!found) return { ok: false, error: 'E-mail ou senha incorretos.' };
    setUser(found);
    return { ok: true };
  }, []);

  const signup = useCallback((name: string, email: string, password: string) => {
    const users = load<User[]>(STORAGE_KEYS.users, []);
    if (users.some((u) => u.email.toLowerCase() === email.toLowerCase())) {
      return { ok: false, error: 'Este e-mail já está cadastrado.' };
    }
    const newUser: User = {
      id: uid(),
      name,
      email,
      password,
      createdAt: new Date().toISOString(),
    };
    users.push(newUser);
    save(STORAGE_KEYS.users, users);
    setUser(newUser);
    return { ok: true };
  }, []);

  const logout = useCallback(() => {
    setUser(null);
  }, []);

  const updateName = useCallback((name: string) => {
    if (!user) return;
    const users = load<User[]>(STORAGE_KEYS.users, []);
    const idx = users.findIndex((u) => u.id === user.id);
    if (idx >= 0) {
      users[idx].name = name;
      save(STORAGE_KEYS.users, users);
    }
    setUser({ ...user, name });
  }, [user]);

  const updatePassword = useCallback(
    (current: string, next: string) => {
      if (!user) return { ok: false, error: 'Não autenticado.' };
      if (user.password !== current) return { ok: false, error: 'Senha atual incorreta.' };
      const users = load<User[]>(STORAGE_KEYS.users, []);
      const idx = users.findIndex((u) => u.id === user.id);
      if (idx >= 0) {
        users[idx].password = next;
        save(STORAGE_KEYS.users, users);
      }
      setUser({ ...user, password: next });
      return { ok: true };
    },
    [user]
  );

  const addBalance = useCallback((amount: number) => {
    setBalance((b) => b + amount);
    setTransactions((t) => [
      {
        id: uid(),
        type: 'deposit',
        description: 'Adição de saldo',
        amount,
        date: new Date().toISOString(),
      },
      ...t,
    ]);
  }, []);

  const purchaseWithBalance = useCallback(
    (total: number) => {
      if (balance < total) return { ok: false, error: 'Saldo insuficiente.' };
      setBalance((b) => b - total);
      setTransactions((t) => [
        {
          id: uid(),
          type: 'purchase',
          description: 'Compra de kit',
          amount: -total,
          date: new Date().toISOString(),
        },
        ...t,
      ]);
      return { ok: true };
    },
    [balance]
  );

  const addOrder = useCallback((order: Omit<Order, 'id' | 'date' | 'status'>) => {
    const newOrder: Order = {
      ...order,
      id: uid(),
      date: new Date().toISOString(),
      status: 'Pedido recebido',
    };
    setOrders((o) => [newOrder, ...o]);
    return newOrder;
  }, []);

  const updateOrderStatus = useCallback((orderId: string, status: Order['status']) => {
    setOrders((o) => o.map((order) => (order.id === orderId ? { ...order, status } : order)));
  }, []);

  const sendBatchDelivery = useCallback((orderIds: string[]) => {
    setOrders((o) =>
      o.map((order) =>
        orderIds.includes(order.id) ? { ...order, status: 'Recebido' as const } : order
      )
    );
  }, []);

  const addNotification = useCallback((n: Omit<Notification, 'id' | 'date' | 'read'>) => {
    setNotifications((list) => [
      {
        ...n,
        id: uid(),
        date: new Date().toISOString(),
        read: false,
      },
      ...list,
    ]);
  }, []);

  const markNotificationsRead = useCallback(() => {
    setNotifications((list) => list.map((n) => ({ ...n, read: true })));
  }, []);

  const sendChatMessage = useCallback((text: string) => {
    const userMsg: ChatMessage = {
      id: uid(),
      text,
      sender: 'user',
      timestamp: new Date().toISOString(),
    };
    setChatMessages((m) => [...m, userMsg]);
    setTimeout(() => {
      const reply: ChatMessage = {
        id: uid(),
        text: 'Recebemos sua mensagem! Nossa equipe responderá em breve.',
        sender: 'support',
        timestamp: new Date().toISOString(),
      };
      setChatMessages((m) => [...m, reply]);
    }, 1200);
  }, []);

  const adminLogin = useCallback((email: string, password: string) => {
    if (
      email.toLowerCase() === DEFAULT_ADMIN.email &&
      password === DEFAULT_ADMIN.password
    ) {
      setAdmin(DEFAULT_ADMIN);
      return { ok: true };
    }
    return { ok: false, error: 'Credenciais administrativas incorretas.' };
  }, []);

  const adminLogout = useCallback(() => {
    setAdmin(null);
  }, []);

  const updateProduct = useCallback((id: string, updates: Partial<ProductConfig>) => {
    setProducts((p) => p.map((prod) => (prod.id === id ? { ...prod, ...updates } : prod)));
  }, []);

  const updateProductIcon = useCallback((id: string, iconData: string) => {
    setProducts((p) => p.map((prod) => (prod.id === id ? { ...prod, iconData } : prod)));
  }, []);

  const removeProductIcon = useCallback((id: string) => {
    setProducts((p) => p.map((prod) => {
      if (prod.id !== id) return prod;
      const { iconData: _, ...rest } = prod;
      return rest;
    }));
  }, []);

  const updateDeliveryTime = useCallback((kit: KitType, time: string) => {
    setDeliveryTimes((dt) => ({ ...dt, [kit]: time }));
  }, []);

  const addSubscription = useCallback((sub: Omit<PlanSubscription, 'id'>) => {
    const newSub: PlanSubscription = { ...sub, id: uid() };
    setSubscriptions((s) => [newSub, ...s]);
    return newSub;
  }, []);

  const incrementSubscriptionDelivery = useCallback((subId: string) => {
    setSubscriptions((s) =>
      s.map((sub) =>
        sub.id === subId
          ? {
              ...sub,
              kitsDelivered: Math.min(sub.kitsDelivered + 1, sub.totalKits),
            }
          : sub
      )
    );
  }, []);

  const unreadCount = notifications.filter((n) => !n.read).length;

  const value: AppContextValue = {
    user,
    login,
    signup,
    logout,
    updateName,
    updatePassword,
    balance,
    addBalance,
    transactions,
    purchaseWithBalance,
    orders,
    addOrder,
    updateOrderStatus,
    sendBatchDelivery,
    notifications,
    unreadCount,
    markNotificationsRead,
    addNotification,
    chatMessages,
    sendChatMessage,
    admin,
    adminLogin,
    adminLogout,
    products,
    updateProduct,
    updateProductIcon,
    removeProductIcon,
    deliveryTimes,
    updateDeliveryTime,
    subscriptions,
    addSubscription,
    incrementSubscriptionDelivery,
  };

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}
