import { useState, useEffect, type ReactNode } from 'react';
import { useApp } from '@/store';
import { MENU_ITEMS, type ScreenName } from '@/types';
import {
  Menu,
  Bell,
  Store,
  X,
  ChevronRight,
  Home as HomeIcon,
  Wallet,
  UserCircle,
  Package,
  MessageCircle,
  Heart,
  Receipt,
  GraduationCap,
  Calculator,
  LogOut,
} from 'lucide-react';

interface AppShellProps {
  currentScreen: ScreenName;
  onNavigate: (screen: ScreenName) => void;
  children: ReactNode;
}

const ICONS: Record<string, typeof Menu> = {
  Home: HomeIcon,
  Wallet,
  UserCircle,
  Package,
  MessageCircle,
  Heart,
  Receipt,
  GraduationCap,
  Calculator,
  LogOut,
};

export function AppShell({ currentScreen, onNavigate, children }: AppShellProps) {
  const { user, logout, unreadCount, markNotificationsRead } = useApp();
  const [menuOpen, setMenuOpen] = useState(false);
  const [notifOpen, setNotifOpen] = useState(false);
  const { notifications } = useApp();

  useEffect(() => {
    if (menuOpen) {
      document.body.style.overflow = 'hidden';
      return () => {
        document.body.style.overflow = '';
      };
    }
  }, [menuOpen]);

  function handleMenuClick(id: string) {
    if (id === 'logout') {
      logout();
      return;
    }
    setMenuOpen(false);
    onNavigate(id as ScreenName);
  }

  function handleBellClick() {
    setNotifOpen(true);
    markNotificationsRead();
  }

  return (
    <div className="min-h-screen bg-gray-100 flex justify-center">
      {/* Phone frame */}
      <div className="w-full max-w-md min-h-screen bg-gray-50 relative shadow-soft">
        {/* Header */}
        <header className="sticky top-0 z-30 bg-white/90 backdrop-blur-lg border-b border-gray-100 px-4 h-14 flex items-center justify-between">
          <button
            onClick={() => setMenuOpen(true)}
            className="w-10 h-10 flex items-center justify-center rounded-xl hover:bg-gray-100 transition-colors"
          >
            <Menu className="w-5 h-5 text-gray-700" />
          </button>

          <div className="flex items-center gap-2">
            <Store className="w-5 h-5 text-brand-blue" strokeWidth={2.5} />
            <span className="font-bold text-gray-800 text-sm">Lojinha do França</span>
          </div>

          <button
            onClick={handleBellClick}
            className="w-10 h-10 flex items-center justify-center rounded-xl hover:bg-gray-100 transition-colors relative"
          >
            <Bell className="w-5 h-5 text-gray-700" />
            {unreadCount > 0 && (
              <span className="absolute top-1.5 right-1.5 w-2.5 h-2.5 bg-red-500 rounded-full ring-2 ring-white animate-pulse-dot" />
            )}
          </button>
        </header>

        {/* Content */}
        <main className="pb-6">{children}</main>

        {/* Slide-in Menu */}
        {menuOpen && (
          <div className="fixed inset-0 z-40">
            <div
              className="absolute inset-0 bg-black/40 backdrop-blur-sm animate-fade-in"
              onClick={() => setMenuOpen(false)}
            />
            <div className="absolute left-0 top-0 bottom-0 w-72 max-w-[80%] bg-white shadow-float animate-slide-in-left flex flex-col">
              {/* Menu header */}
              <div className="bg-gradient-to-br from-brand-blue to-brand-green p-5 pt-8">
                <div className="flex justify-end mb-2">
                  <button
                    onClick={() => setMenuOpen(false)}
                    className="w-8 h-8 flex items-center justify-center rounded-full bg-white/20 hover:bg-white/30 transition-colors"
                  >
                    <X className="w-4 h-4 text-white" />
                  </button>
                </div>
                <div className="w-14 h-14 rounded-2xl bg-white/20 flex items-center justify-center mb-3">
                  <Store className="w-7 h-7 text-white" strokeWidth={2.5} />
                </div>
                <p className="text-white font-bold text-lg">Lojinha do França</p>
                <p className="text-white/80 text-sm truncate">{user?.email}</p>
              </div>

              {/* Menu items */}
              <nav className="flex-1 overflow-y-auto py-2">
                {MENU_ITEMS.map((item) => {
                  const Icon = ICONS[item.icon] || Menu;
                  const active = currentScreen === item.id;
                  return (
                    <button
                      key={item.id}
                      onClick={() => handleMenuClick(item.id)}
                      className={`
                        w-full flex items-center gap-3 px-5 py-3.5 text-left transition-colors
                        ${active ? 'bg-blue-50 text-brand-blue font-semibold' : 'text-gray-700 hover:bg-gray-50'}
                      `}
                    >
                      <Icon className="w-5 h-5 shrink-0" />
                      <span className="text-sm flex-1">{item.label}</span>
                      {active && <ChevronRight className="w-4 h-4" />}
                    </button>
                  );
                })}
              </nav>
            </div>
          </div>
        )}

        {/* Notifications dropdown */}
        {notifOpen && (
          <div
            className="fixed inset-0 z-40"
            onClick={() => setNotifOpen(false)}
          >
            <div className="absolute top-14 right-2 w-72 max-w-[90%] bg-white rounded-2xl shadow-float border border-gray-100 animate-scale-in origin-top-right">
              <div className="p-4 border-b border-gray-100">
                <h3 className="font-bold text-gray-800">Notificações</h3>
              </div>
              <div className="max-h-80 overflow-y-auto">
                {notifications.length === 0 ? (
                  <div className="p-6 text-center text-sm text-gray-400">
                    Nenhuma notificação ainda.
                  </div>
                ) : (
                  notifications.map((n) => (
                    <div
                      key={n.id}
                      className="p-4 border-b border-gray-50 last:border-0"
                    >
                      <p className="font-semibold text-sm text-gray-800">{n.title}</p>
                      <p className="text-sm text-gray-500 mt-0.5">{n.message}</p>
                      <p className="text-xs text-gray-400 mt-1">
                        {new Date(n.date).toLocaleString('pt-BR')}
                      </p>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
