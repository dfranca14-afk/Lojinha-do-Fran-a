import { useState, useEffect, type ReactNode } from 'react';
import { useApp } from '@/store';
import { ADMIN_MENU_ITEMS } from '@/types';
import {
  Store,
  X,
  ChevronRight,
  LayoutDashboard,
  ShoppingBag,
  Package,
  Clock,
  LogOut,
  Menu as MenuIcon,
  ShieldCheck,
} from 'lucide-react';

interface AdminShellProps {
  currentScreen: string;
  onNavigate: (screen: string) => void;
  onExit: () => void;
  children: ReactNode;
}

const ICONS: Record<string, typeof Store> = {
  LayoutDashboard,
  ShoppingBag,
  Package,
  Clock,
};

export function AdminShell({ currentScreen, onNavigate, onExit, children }: AdminShellProps) {
  const { admin, adminLogout } = useApp();
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    if (menuOpen) {
      document.body.style.overflow = 'hidden';
      return () => {
        document.body.style.overflow = '';
      };
    }
  }, [menuOpen]);

  function handleMenuClick(id: string) {
    setMenuOpen(false);
    onNavigate(id);
  }

  return (
    <div className="min-h-screen bg-gray-100 flex justify-center">
      <div className="w-full max-w-md min-h-screen bg-gray-50 relative shadow-soft">
        {/* Header */}
        <header className="sticky top-0 z-30 bg-gray-900/95 backdrop-blur-lg px-4 h-14 flex items-center justify-between">
          <button
            onClick={() => setMenuOpen(true)}
            className="w-10 h-10 flex items-center justify-center rounded-xl hover:bg-white/10 transition-colors"
          >
            <MenuIcon className="w-5 h-5 text-white" />
          </button>

          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-brand-gold" strokeWidth={2.5} />
            <span className="font-bold text-white text-sm">Admin — Lojinha do França</span>
          </div>

          <button
            onClick={() => {
              adminLogout();
              onExit();
            }}
            className="w-10 h-10 flex items-center justify-center rounded-xl hover:bg-white/10 transition-colors"
          >
            <LogOut className="w-5 h-5 text-white" />
          </button>
        </header>

        {/* Content */}
        <main className="pb-6">{children}</main>

        {/* Slide-in Menu */}
        {menuOpen && (
          <div className="fixed inset-0 z-40">
            <div
              className="absolute inset-0 bg-black/40 backdrop-blur-sm animate-fade-in"
              onClick={() => setMenuOpen(false)}
            />
            <div className="absolute left-0 top-0 bottom-0 w-72 max-w-[80%] bg-white shadow-float animate-slide-in-left flex flex-col">
              {/* Menu header */}
              <div className="bg-gradient-to-br from-gray-800 to-gray-900 p-5 pt-8">
                <div className="flex justify-end mb-2">
                  <button
                    onClick={() => setMenuOpen(false)}
                    className="w-8 h-8 flex items-center justify-center rounded-full bg-white/20 hover:bg-white/30 transition-colors"
                  >
                    <X className="w-4 h-4 text-white" />
                  </button>
                </div>
                <div className="w-14 h-14 rounded-2xl bg-white/10 flex items-center justify-center mb-3">
                  <ShieldCheck className="w-7 h-7 text-brand-gold" strokeWidth={2.5} />
                </div>
                <p className="text-white font-bold text-lg">Área Administrativa</p>
                <p className="text-white/60 text-sm truncate">{admin?.email}</p>
              </div>

              {/* Menu items */}
              <nav className="flex-1 overflow-y-auto py-2">
                {ADMIN_MENU_ITEMS.map((item) => {
                  const Icon = ICONS[item.icon] || Store;
                  const active = currentScreen === item.id;
                  return (
                    <button
                      key={item.id}
                      onClick={() => handleMenuClick(item.id)}
                      className={`
                        w-full flex items-center gap-3 px-5 py-3.5 text-left transition-colors
                        ${active ? 'bg-blue-50 text-brand-blue font-semibold' : 'text-gray-700 hover:bg-gray-50'}
                      `}
                    >
                      <Icon className="w-5 h-5 shrink-0" />
                      <span className="text-sm flex-1">{item.label}</span>
                      {active && <ChevronRight className="w-4 h-4" />}
                    </button>
                  );
                })}
                <div className="border-t border-gray-100 mt-2 pt-2">
                  <button
                    onClick={() => {
                      adminLogout();
                      onExit();
                    }}
                    className="w-full flex items-center gap-3 px-5 py-3.5 text-left text-red-500 hover:bg-red-50 transition-colors"
                  >
                    <LogOut className="w-5 h-5 shrink-0" />
                    <span className="text-sm">Sair do admin</span>
                  </button>
                </div>
              </nav>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
