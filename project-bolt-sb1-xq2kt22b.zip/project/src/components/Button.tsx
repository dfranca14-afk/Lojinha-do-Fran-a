import { type ButtonHTMLAttributes, type ReactNode } from 'react';

type Variant = 'primary' | 'secondary' | 'green' | 'white' | 'ghost' | 'danger';

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: Variant;
  children: ReactNode;
  fullWidth?: boolean;
}

const variants: Record<Variant, string> = {
  primary:
    'bg-brand-blue text-white shadow-soft hover:bg-blue-600 active:scale-[0.98]',
  secondary:
    'bg-brand-gray text-gray-700 hover:bg-gray-200 active:scale-[0.98]',
  green:
    'bg-brand-green text-white shadow-soft hover:bg-brand-green-dark active:scale-[0.98]',
  white:
    'bg-white text-brand-blue border-2 border-brand-blue hover:bg-blue-50 active:scale-[0.98]',
  ghost: 'bg-transparent text-gray-600 hover:bg-gray-100',
  danger:
    'bg-red-500 text-white shadow-soft hover:bg-red-600 active:scale-[0.98]',
};

export function Button({
  variant = 'primary',
  children,
  fullWidth = false,
  className = '',
  disabled = false,
  ...props
}: ButtonProps) {
  return (
    <button
      className={`
        ${variants[variant]}
        ${fullWidth ? 'w-full' : ''}
        ${disabled ? 'opacity-40 cursor-not-allowed' : 'transition-all duration-200'}
        px-5 py-3.5 rounded-2xl font-semibold text-sm
        flex items-center justify-center gap-2
        ${className}
      `}
      disabled={disabled}
      {...props}
    >
      {children}
    </button>
  );
}
